package com.bms.paypal;


import java.sql.*;

public class SQLConnection {

	private static Connection con;
	
		public static Connection getConnection(){
	
		if(con!=null){
			return con;
		}
		else{
				try{  
						Class.forName("com.mysql.jdbc.Driver");
						con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bms","root","SqlRoot3!");  
						System.out.println("returning connection object");
					}
				catch(Exception e){ 
					System.out.println(e);}  
		
				finally{
					System.out.println("returning connection object");
					return con;
					}
			}
	}
}

