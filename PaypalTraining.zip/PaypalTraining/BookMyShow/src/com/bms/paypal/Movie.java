package com.bms.paypal;

public class Movie {

		private String movieName;
		private int movieID;
		
		public String getMovieName() {
			return movieName;
		}
		public void setMovieName(String movieName) {
			this.movieName = movieName;
		}
		public int getMovieID() {
			return movieID;
		}
		public void setMovieID(int movieID) {
			this.movieID = movieID;
		}
	}	

