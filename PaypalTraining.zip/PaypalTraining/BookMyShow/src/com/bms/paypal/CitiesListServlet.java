package com.bms.paypal;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import com.google.gson.Gson;
import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class CitiesList
 */
@WebServlet("/CitiesListServlet")
public class CitiesListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ArrayList<City> myCityList;
	Connection con=SQLConnection.getConnection();
	ArrayList<Movie> movieList=new ArrayList<Movie>();

	
    /**
     * Default constructor. 
     */
    public CitiesListServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    // On load , list of cities , movies and theatres getting displayed..Ajax on change event is called.
    //On submit Go to seatSelection.jsp 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			myCityList = GetCityList();
			System.out.println(myCityList.toString());
			request.setAttribute("list", myCityList);
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	
	private ArrayList<City> GetCityList( )
	{
		ArrayList<City> arList = new ArrayList<City>();
		try {
			Statement stmt	=	con.createStatement();
			String sql= "select * from citylist";
			ResultSet rs= stmt.executeQuery(sql);
			while(rs.next()){
					City cities=new City();
					cities.setcID(rs.getInt(1));
					cities.setcName(rs.getString(2));
					arList.add(cities);
					System.out.println(arList.get(0));
			}
		}
		catch(SQLException e){
				e.printStackTrace();
		}
		return arList;
	}
	
	
	

	public ArrayList<Movie> getAllmovies(){
		try{
					  
					  Connection con=SQLConnection.getConnection();
					  
			    	  ResultSet rs=stmt.executeQuery(sql);
			    	  while(rs.next()){
			    		  City cities=new City();
			    		  cities.setcID(rs.getInt(1));
			    		  cities.setcName(rs.getString(2));
			    		  cityList.add(cities);
			    	  }
			    	  
				}
				catch(SQLException e){
					e.printStackTrace();
				}
		
			finally{
				return cityList;
			}


}

}
