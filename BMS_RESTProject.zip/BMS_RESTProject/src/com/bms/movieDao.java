package com.bms;

public class movieDao {
	final private static String JDBC_DRIVER="com.mysql.jdbc.Driver";  
    final private static String DB_URL="jdbc:mysql://localhost/bms";
    final private static String USER = "root";
    final private static String PASS = "Hisweety@03";

		
	public void getMovieList()
	{
		
		
		
	}
	
}
