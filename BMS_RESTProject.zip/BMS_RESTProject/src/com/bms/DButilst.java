package com.bms;
import java.sql.Connection;
import java.sql.DriverManager;

public class DButilst {

	final private static String JDBC_DRIVER="com.mysql.jdbc.Driver";  
    final private static String DB_URL="jdbc:mysql://localhost/bms";
    final private static String USER = "root";
    final private static String PASS = "Hisweety@03";
    private static Connection con=null;
    
    // Creating a Singleton instance of database connection.
    static public Connection getConnection(){
    	try{
    		if(con!=null){
    			Class.forName(JDBC_DRIVER);
    			con=DriverManager.getConnection(DB_URL,USER,PASS);
			}
    	}
    	finally{
    		return con;
    	}
    	
    }
}