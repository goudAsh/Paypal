package com.bms;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
@Path("/CityService")
public class cityService {
	
	
	@GET
	@Path("/cities")
	public ArrayList<City> getCities(){
		cityDao citydao=new cityDao();
		return	citydao.getAllcities();
	}
	
}
