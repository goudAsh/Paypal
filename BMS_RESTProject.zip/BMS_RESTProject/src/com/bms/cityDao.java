package com.bms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class cityDao {
	
	public ArrayList<City> getAllcities(){
		ArrayList<City> cityList=new ArrayList<City>();
		try{
					  Statement stmt=DButilst.getConnection().createStatement();
			    	  String sql="select * from cities";
			    	  ResultSet rs=stmt.executeQuery(sql);
			    	  while(rs.next()){
			    		  City cities=new City();
			    		  cities.setcID(rs.getInt(1));
			    		  cities.setcName(rs.getString(2));
			    		  cityList.add(cities);
			    	  }
			    	  
				}
				catch(SQLException e){
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
			finally{
				return cityList;
			}
				
			}

}
		
		
		
		
		
		

