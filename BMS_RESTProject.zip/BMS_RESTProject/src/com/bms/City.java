package com.bms;

public class City {
	private String cName;
	private int cID;
	
	public City(){}
	
	public City(String cName, int cID) {
		this.cName = cName;
		this.cID = cID;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public int getcID() {
		return cID;
	}
	public void setcID(int cID) {
		this.cID = cID;
	}
	
	
	
}
