package codemiles;

/**
 *
 * @author codemiles Team
 */
public class Userentry {
    String firstName;
    String lastName;
    String email;

    public void setEmail(String email) {
        this.email = email;
        System.out.println(email);
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
        System.out.println(firstName);
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
        System.out.println(lastName);
    }

    public String getEmail() {
        return email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
    
} 