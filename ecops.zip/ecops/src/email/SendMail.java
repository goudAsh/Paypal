package email;

import javax.mail.*;
import javax.mail.internet.*;

import java.security.Security;
import java.util.*;

public class SendMail
{

  private static final String SMTP_HOST_NAME = "smtp.gmail.com";
  private static final String SMTP_AUTH_USER = "prashanthyered@gmail.com";
  private static final String SMTP_AUTH_PWD  = "ismylogo";

  public static void main(String args[]) throws Exception
  {
	  SendMail smtpMailSender = new SendMail();

	  String[] recepients = {"prashanthyered@gmail.com"};
	  String subject = "Welcome to Virtual Medical Home";
	  String message = "Congratulations, You are now a part of VMH. Your Login Details are as follows:\n Username:" + "Username" + " \n Password:" + "password" + "." ;
	  String from = "prashanthyered@gmail.com";

	  smtpMailSender.postMail(recepients,subject,message,from);

  }

  public void postMail( String recipients[ ], String subject,
                            String message , String from) throws MessagingException
  {
    boolean debug = false;
    Security.setProperty("ssl.SocketFactory.provider", "com.ibm.jsse2.SSLSocketFactoryImpl");
    Security.setProperty("ssl.ServerSocketFactory.provider", "com.ibm.jsse2.SSLServerSocketFactoryImpl");

     //Set the host smtp address
     Properties props = new Properties();
     props.setProperty("mail.transport.protocol", "smtp");
     props.setProperty("mail.host", SMTP_HOST_NAME);
     props.put("mail.smtp.auth", "true");
     props.put("mail.smtp.port", "465");
     props.put("mail.smtp.socketFactory.port", "465");
     props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
     props.put("mail.smtp.socketFactory.fallback", "false");
     props.setProperty("mail.smtp.quitwait", "false");

    Authenticator auth = new SMTPAuthenticator();
    Session session = Session.getInstance(props, auth);

    session.setDebug(debug);

    // create a message
    Message msg = new MimeMessage(session);

    // set the from and to address
    InternetAddress addressFrom = new InternetAddress(from);
    msg.setFrom(addressFrom);

    InternetAddress[] addressTo = new InternetAddress[recipients.length];
    for (int i = 0; i < recipients.length; i++)
    {
        addressTo[i] = new InternetAddress(recipients[i]);
    }
    msg.setRecipients(Message.RecipientType.TO, addressTo);


    // Setting the Subject and Content Type
    msg.setSubject(subject);
    msg.setContent(message, "text/html");
    Transport.send(msg);
 }


/**
* SimpleAuthenticator is used to do simple authentication
* when the SMTP server requires it.
*/
private class SMTPAuthenticator extends javax.mail.Authenticator
{

    public PasswordAuthentication getPasswordAuthentication()
    {
        String username = SMTP_AUTH_USER;
        String password = SMTP_AUTH_PWD;
        return new PasswordAuthentication(username, password);
    }
}

}


