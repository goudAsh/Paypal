package db;

import java.sql.*;


public class Topic
{

public String topic;
public String topicdis;
public Topic()
{

topic="";
topicdis="";
}


public void setTopic(String val)
{
topic=val;
}

public void setTopicdis(String val)
{
topicdis=val;
}
public String getTopic()
{
return topic;
}
public String getTopicdis()
{
return topicdis;
}
public void CreateTopic()
{
try

{
Class.forName("com.ibm.db2.jcc.DB2Driver");
Connection connect = DriverManager.getConnection("jdbc:db2:SAMPLE");
PreparedStatement prst = connect.prepareStatement("insert into CLIENT.t1 values(?,?)");
prst.setString(1,topic);
prst.setString(2,topicdis);
prst.execute();
connect.close();
}

catch(Exception e)
{
System.out.println(e);
}
}
}
