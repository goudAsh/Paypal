package sendMail;
import java.util.Properties;
import java.security.*;
import javax.mail.*;
import javax.mail.internet.*;
public class sendMail 
{
//public static void main(String args[]) throws Exception {
//	sendmail("raagsk@gmail.com","TestMail","This is a test Mail");
/*
String host = "smtp.gmail.com";
String from = "prashanthyered@gmail.com";
String to = "raagsk@gmail.com";
String pwd="mylogois";
Properties prop=System.getProperties();

Security.setProperty("ssl.SocketFactory.provider", "com.ibm.jsse2.SSLSocketFactoryImpl");
Security.setProperty("ssl.ServerSocketFactory.provider", "com.ibm.jsse2.SSLServerSocketFactoryImpl");

prop.put("mail.smtp.starttls.enable","true");
prop.put("mail.smtp.host",host);
prop.put("mail.smtp.user", from);
prop.put("mail.smtp.password", pwd);
prop.put("mail.smtp.port", 587);
prop.put("mail.smtp.auth", "true");
Session sesl= Session.getDefaultInstance(prop,null);
MimeMessage msg = new MimeMessage(sesl);
msg.setFrom(new InternetAddress(from ));
msg.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
msg.setSubject("urgent message");
msg.setText("you won the lottery");
Transport transport =sesl.getTransport("smtp");
transport.connect(host,from,pwd);
transport.sendMessage(msg,msg.getAllRecipients());
transport.close();
*/
//}

public static int sendmail(String to,String subject,String mailText)
{
	String host = "smtp.gmail.com";
	String from = "prashanthyered@gmail.com";
	//String to = "raagsk@gmail.com";
	String pwd="ismylogo";
try{
	Properties prop=System.getProperties();

	Security.setProperty("ssl.SocketFactory.provider", "com.ibm.jsse2.SSLSocketFactoryImpl");
	Security.setProperty("ssl.ServerSocketFactory.provider", "com.ibm.jsse2.SSLServerSocketFactoryImpl");

	prop.put("mail.smtp.starttls.enable","true");
	prop.put("mail.smtp.host",host);
	prop.put("mail.smtp.user", from);
	prop.put("mail.smtp.password", pwd);
	prop.put("mail.smtp.port", 587);
	prop.put("mail.smtp.auth", "true");
	Session sesl= Session.getDefaultInstance(prop,null);
	MimeMessage msg = new MimeMessage(sesl);
	msg.setFrom(new InternetAddress(from));
	msg.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	msg.setSubject(subject);
	msg.setText(mailText);
	Transport transport =sesl.getTransport("smtp");
	transport.connect(host,from,pwd);
	transport.sendMessage(msg,msg.getAllRecipients());
	transport.close();
	return 1;
}
catch(Exception ex){return 0;}
}
}