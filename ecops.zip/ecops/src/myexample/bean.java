package myexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

 
public class bean 
{
    
	private int msgid;
	private int ex;
    private String message1;
    private Connection connection=null;
	String connectionURL = "jdbc:db2:SAMPLE";
	public bean() 
    {
         	try 
         	{
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			connection = DriverManager.getConnection(connectionURL, "Client", "client"); 
			}
         	catch(Exception e)
         	{
			System.out.println("Exception is ;"+e);
			}
        
    }  
    public void setmsgid(int msgid)
	{
		this.msgid = msgid;
	}
 
	public int getmsgid()
	{
		return (this.msgid);
	}
	
	public void setex()
	{
		this.ex=10;
	}
	
	public int getex()
	{
		return ex;
	}

	
	public void setmessage1(String message1)
	{
		this.message1 = message1;
	}
 
	public String getmessage1()
	{
		return(this.message1);
	}
	
	     
    public String insert()
    {
        
       try
       {
            String sql = "insert into CLIENT.t1 values('"+msgid+"','"+message1+"')";
			Statement s = connection.createStatement();
			s.executeUpdate(sql);
			s.close ();
		}
       catch(Exception e)
       {
			System.out.println("Exception is ;"+e);
       }

       return "done!";
    }
}