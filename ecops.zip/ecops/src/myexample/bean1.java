package myexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

 
public class bean1 
{
    
    private int msgid;
	private String message1;
    private Connection connection=null;
	String connectionURL = "jdbc:db2:SAMPLE";
	
	    
    public bean1() 
    {
         try {
			 // Load the database driver
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			// Get a Connection to the database
			connection = DriverManager.getConnection(connectionURL, "Client", "client"); 
			}catch(Exception e){
			System.out.println("Exception is ;"+e);
			}
        
    }  
    public void setmsgid(int msgid)
	{
		this.msgid = msgid;
	}
 
	public int getmsgid()
	{
		return (this.msgid);
	}

	public void setmessage1(String message1)
	{
		this.message1 = message1;
	}
 
	public String getmessage1()
	{
		return (this.message1);
	}
     
    public void insert()
    {
        
       try
       {
            String sql = "insert into CLIENT.t1 values('"+msgid+"','"+message1+"')";
			Statement s = connection.createStatement();
			s.executeUpdate (sql);
			s.close ();
		}catch(Exception e){
			System.out.println("Exception is ;"+e);
		}
    }
    
}