package myexample;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DisplayImage extends  HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		//PrintWriter pw = response.getWriter();
		
		try
		{
		Class.forName("com.ibm.db2.jcc.DB2Driver");
		Connection con=DriverManager.getConnection("jdbc:db2:SAMPLE");
		Statement st1=con.createStatement();
		ResultSet rs1 = st1.executeQuery("select image from CLIENT.IMG");
		String imgLen="";

		if(rs1.next())
		{
		imgLen = rs1.getString(1);
		System.out.println(imgLen.length());
		}
		rs1 = st1.executeQuery("select image from CLIENT.IMG");
		if(rs1.next())
		{
		int len = imgLen.length();
		byte [] rb = new byte[len];
		InputStream readImg = rs1.getBinaryStream(1);
		int index=readImg.read(rb, 0, len);
		System.out.println("index"+index);
		st1.close();
		response.reset();
		response.setContentType("image/jpg");
		response.getOutputStream().write(rb,0,len);
		response.getOutputStream().flush();
		}
		}
		catch (Exception e)
		{
		e.printStackTrace();
		}
	}
}