
function validatefir()
			{
			var firno=document.getElementById("firno");
			if(firno.value=="")
			{
				firno.style.borderColor="red";
				document.getElementById("firno-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">FIR No cannot be blank</span>';
				document.getElementById("firno-error").style.display="block";
			}
			
			else
			{
			firno.style.borderColor=" #00CC00";
			document.getElementById("firno-error").style.display="none";
			}
			}
function validatedate()
{
var date=document.getElementById("date");
if(date.value=="")
{
	date.style.borderColor="red";
	document.getElementById("date-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Date cannot be blank</span>';
	document.getElementById("date-error").style.display="block";
}  
else
{
date.style.borderColor=" #00CC00";
document.getElementById("date-error").style.display="none";
}
}		
function validateactioncode()
{
var actioncode=document.getElementById("actioncode");
if(actioncode.value=="")
{
	actioncode.style.borderColor="red";
	document.getElementById("actioncode-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Action code cannot be blank</span>';
	document.getElementById("actioncode-error").style.display="block";
}  
else
{
actioncode.style.borderColor=" #00CC00";
document.getElementById("actioncode-error").style.display="none";
}
}	
function validateactiondesc()
{
var actiondesc=document.getElementById("actiondesc");
if(actiondesc.value=="")
{
	actiondesc.style.borderColor="red";
	document.getElementById("actiondesc-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Action description cannot be blank</span>';
	document.getElementById("actiondesc-error").style.display="block";
}  
else
{
actiondesc.style.borderColor=" #00CC00";
document.getElementById("actiondesc-error").style.display="none";
}
}	
function validatefrom()
{
var from=document.getElementById("from");
if(from.value=="")
{
	from.style.borderColor="red";
	document.getElementById("from-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the From date field</span>';
	document.getElementById("from-error").style.display="block";
}  
else
{
from.style.borderColor=" #00CC00";
document.getElementById("from-error").style.display="none";
}
}
function validateto()
{
var to=document.getElementById("to");
if(to.value=="")
{
	to.style.borderColor="red";
	document.getElementById("to-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the To date field</span>';
	document.getElementById("to-error").style.display="block";
}  
else
{
to.style.borderColor=" #00CC00";
document.getElementById("to-error").style.display="none";
}
}
function validateinfo()
{
var info=document.getElementById("info");
if(info.value=="")
{
	info.style.borderColor="red";
	document.getElementById("info-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Date field</span>';
	document.getElementById("info-error").style.display="block";
}  
else
{
info.style.borderColor=" #00CC00";
document.getElementById("info-error").style.display="none";
}
}
function validatedist()
{
var dist=document.getElementById("dist");
if(dist.value=="")
{
	dist.style.borderColor="red";
	document.getElementById("dist-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the distance</span>';
	document.getElementById("dist-error").style.display="block";
}  
else
{
dist.style.borderColor=" #00CC00";
document.getElementById("dist-error").style.display="none";
}
}
function validatebeat()
{
var beatno=document.getElementById("beatno");
if(beatno.value=="")
{
	beatno.style.borderColor="red";
	document.getElementById("beat-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the beat no</span>';
	document.getElementById("beat-error").style.display="block";
}  
else
{
beatno.style.borderColor=" #00CC00";
document.getElementById("beat-error").style.display="none";
}
}
function validatestreet()
{
var street=document.getElementById("street");
if(street.value=="")
{
	street.style.borderColor="red";
	document.getElementById("street-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the street</span>';
	document.getElementById("street-error").style.display="block";
}  
else
{
street.style.borderColor=" #00CC00";
document.getElementById("street-error").style.display="none";
}
}
function validatearea()
{
var area=document.getElementById("area");
if(area.value=="")
{
	area.style.borderColor="red";
	document.getElementById("area-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the area</span>';
	document.getElementById("area-error").style.display="block";
}  
else
{
area.style.borderColor=" #00CC00";
document.getElementById("area-error").style.display="none";
}
}
function validatecity()
{
var city=document.getElementById("city");
if(city.value=="")
{
	city.style.borderColor="red";
	document.getElementById("city-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the city</span>';
	document.getElementById("city-error").style.display="block";
}  
else
{
city.style.borderColor=" #00CC00";
document.getElementById("city-error").style.display="none";
}
}
function validatename()
{
var name=document.getElementById("name");
if(name.value=="")
{
	name.style.borderColor="red";
	document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Name</span>';
	document.getElementById("name-error").style.display="block";
}  
else
{
name.style.borderColor=" #00CC00";
document.getElementById("name-error").style.display="none";
}
}
function validatefname()
{
var fname=document.getElementById("fname");
if(fname.value=="")
{
	fname.style.borderColor="red";
	document.getElementById("fname-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the above field</span>';
	document.getElementById("fname-error").style.display="block";
}  
else
{
fname.style.borderColor=" #00CC00";
document.getElementById("fname-error").style.display="none";
}
}
function validatedob()
{
var dob=document.getElementById("dob");
if(dob.value=="")
{
	dob.style.borderColor="red";
	document.getElementById("dob-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Date of Birth </span>';
	document.getElementById("dob-error").style.display="block";
}  
else
{
dob.style.borderColor=" #00CC00";
document.getElementById("dob-error").style.display="none";
}
}
function validatestreet1()
{
var street1=document.getElementById("street1");
if(street1.value=="")
{
	street1.style.borderColor="red";
	document.getElementById("street1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the street</span>';
	document.getElementById("street1-error").style.display="block";
}  
else
{
street1.style.borderColor=" #00CC00";
document.getElementById("street1-error").style.display="none";
}
}
function validatearea1()
{
var area1=document.getElementById("area1");
if(area1.value=="")
{
	area1.style.borderColor="red";
	document.getElementById("area1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the area</span>';
	document.getElementById("area1-error").style.display="block";
}  
else
{
area1.style.borderColor=" #00CC00";
document.getElementById("area1-error").style.display="none";
}
}
function validatecity1()
{
var city1=document.getElementById("city1");
if(city1.value=="")
{
	city1.style.borderColor="red";
	document.getElementById("city1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the city</span>';
	document.getElementById("city1-error").style.display="block";
}  
else
{
city1.style.borderColor=" #00CC00";
document.getElementById("city1-error").style.display="none";
}
}
function validateocc()
{
var occ=document.getElementById("occ");
if(occ.value=="")
{
	occ.style.borderColor="red";
	document.getElementById("occ-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the occupation</span>';
	document.getElementById("occ-error").style.display="block";
}  
else
{
occ.style.borderColor=" #00CC00";
document.getElementById("occ-error").style.display="none";
}
}
function validatename2()
{
var name2=document.getElementById("name2");
if(name2.value=="")
{
	name2.style.borderColor="red";
	document.getElementById("name2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Name</span>';
	document.getElementById("name2-error").style.display="block";
}  
else
{
name2.style.borderColor=" #00CC00";
document.getElementById("name2-error").style.display="none";
}
}
function validatedob2()
{
var dob2=document.getElementById("dob2");
if(dob2.value=="")
{
	dob2.style.borderColor="red";
	document.getElementById("dob2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Date of Birth </span>';
	document.getElementById("dob2-error").style.display="block";
}  
else
{
dob2.style.borderColor=" #00CC00";
document.getElementById("dob2-error").style.display="none";
}
}
function validatefname2()
{
var fname2=document.getElementById("fname2");
if(fname2.value=="")
{
	fname2.style.borderColor="red";
	document.getElementById("fname2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Father Name</span>';
	document.getElementById("fname2-error").style.display="block";
}  
else
{
fname2.style.borderColor=" #00CC00";
document.getElementById("fname2-error").style.display="none";
}
}
function validateocc2()
{
var occ2=document.getElementById("occ2");
if(occ2.value=="")
{
	occ2.style.borderColor="red";
	document.getElementById("occ2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the occupation</span>';
	document.getElementById("occ2-error").style.display="block";
}  
else
{
occ2.style.borderColor=" #00CC00";
document.getElementById("occ2-error").style.display="none";
}
}
function validateaddr2()
{
var addr2=document.getElementById("addr2");
if(addr2.value=="")
{
	addr2.style.borderColor="red";
	document.getElementById("addr2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Address</span>';
	document.getElementById("addr2-error").style.display="block";
}  
else
{
addr2.style.borderColor=" #00CC00";
document.getElementById("addr2-error").style.display="none";
}
}
function validateheight()
{
var height=document.getElementById("height");
if(height.value=="")
{
	height.style.borderColor="red";
	document.getElementById("height-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Height</span>';
	document.getElementById("height-error").style.display="block";
}  
else
{
height.style.borderColor=" #00CC00";
document.getElementById("height-error").style.display="none";
}
}
function validatestate1()
{
var state1=document.getElementById("state1");
if(state1.value=="")
{
	state1.style.borderColor="red";
	document.getElementById("state1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the State</span>';
	document.getElementById("state1-error").style.display="block";
}  
else
{
state1.style.borderColor=" #00CC00";
document.getElementById("state1-error").style.display="none";
}
}
function validatecontents()
{
var contents=document.getElementById("contents");
if(contents.value=="")
{
	contents.style.borderColor="red";
	document.getElementById("contents-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the FIR Contents</span>';
	document.getElementById("contents-error").style.display="block";
}  
else
{
contents.style.borderColor=" #00CC00";
document.getElementById("content-error").style.display="none";
}
}

function validatecompno()
{
var compno=document.getElementById("compno");
if(compno.value=="0")
{
	compno.style.borderColor="red";
	document.getElementById("compno-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please select a Complaint No</span>';
	document.getElementById("compno-error").style.display="block";
}  
else
{
	compno.style.borderColor=" #00CC00";
document.getElementById("compno-error").style.display="none";
}
}

function validatedistrict()
{
var district=document.getElementById("district");
if(district.value=="0")
{
	district.style.borderColor="red";
	document.getElementById("district-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please select a District</span>';
	document.getElementById("district-error").style.display="block";
}  
else
{
	district.style.borderColor=" #00CC00";
document.getElementById("district-error").style.display="none";
}
}


function validateform()
{
	var firno=document.getElementById("firno");
	var date=document.getElementById("date");
	var actioncode=document.getElementById("actioncode");
	var from=document.getElementById("from");
	var to=document.getElementById("to");
	var info=document.getElementById("info");
	var beatno=document.getElementById("beatno");
	var street=document.getElementById("street");
	var area=document.getElementById("area");
	var city=document.getElementById("city");
	var dist=document.getElementById("dist");
	var name=document.getElementById("name");
	var dob=document.getElementById("dob");
	var occ=document.getElementById("occ");
	var street1=document.getElementById("street1");
	var area1=document.getElementById("area1");
	var city1=document.getElementById("city1");
	var state1=document.getElementById("state1");
	var fname2=document.getElementById("fname2");
	var name2=document.getElementById("name2");
	var dob2=document.getElementById("dob2");
	var occ2=document.getElementById("occ2");
	var addr2=document.getElementById("addr2");
	var height=document.getElementById("height");
	var contents=document.getElementById("contents");
	var kgid=document.getElementById("kgid");
	var name5=document.getElementById("name2");
	var acttaken=document.getElementById("acttaken");
	if(firno.value=="" ||  date.value=="" || actioncode.value=="" || from.value=="" || to.value=="" || info.value=="" || dist.value=="" || beatno.value=="" || street.value=="" || area.value=="" || city.value=="" || fmname.value=="" ||
			name.value=="" || dob.value=="" || occ.value=="" || street1.value=="" || area1.value=="" || city1.value=="" || state1.value=="" ||  contents.value=="" || acttaken.value=="" || name5.value=="" || kgid.value=="")
	{

	document.getElementById("form-error").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("form-error").style.display="block";

	}
	else
		{
	document.getElementById("form-error").style.display="none";
	login();
		}
	}
function login()
{
	$('form-error').style.display="block";
	$('form-error').innerHTML='<img src="../image/8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
		new Ajax.Request( '../actions/see.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
		if( transport.responseText.match( /1/ ) )
	$('form-error').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>Inserted Successfully!</b></span>';
	if( transport.responseText.match( /0/ ) )
		$('form-error').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Insertion Failed! Try Again.</b></span>';
	
	}
		} );
}


