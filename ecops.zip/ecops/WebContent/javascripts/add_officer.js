function validate_kgid()
			{
			var kgid=document.getElementById("kgid");
			if(kgid.value=="")
			{
				kgid.style.borderColor="red";
				document.getElementById("kgid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">KGID cannot be blank</span>';
				document.getElementById("kgid-error").style.display="block";
			}  
			else
			{
			kgid.style.borderColor="#00CC00";
			document.getElementById("kgid-error").style.display="none";
			}
}

function validate_name()
{
var name=document.getElementById("name");
if(name.value==" ")
{
	name.style.borderColor="red";
	document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
	document.getElementById("name-error").style.display="block";
}  
else
{
name.style.borderColor=" #00CC00";
document.getElementById("name-error").style.display="none";
}
}


 		function validate_password()
 		{
 			var pass=document.getElementById("password");
 			if(pass.value==" ")
 			{
 				pass.style.borderColor="red";
 				document.getElementById("pass-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">password cannot be blank</span>';
 				document.getElementById("pass-error").style.display="block";
 			}  
 			else
 			{
 				pass.style.borderColor=" #00CC00";
 				document.getElementById("pass-error").style.display="none";
 			}
 		}
 		
 		function validate_email()
		{
		var emailid=document.getElementById("email-id");
		if(emailid.value=="")
		{
			emailid.style.borderColor="red";
			document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot be blank</span>';
			document.getElementById("emailid-error").style.display="block";
		} 
		else if(emailid.value.indexOf(' ')>=0)
		{
			emailid.style.borderColor="red";
			document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot have blank space</span>';
			document.getElementById("emailid-error").style.display="block";
		}
        else if(emailid.value.indexOf('@')==-1)
        {
        	emailid.style.borderColor="red";
			document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
			document.getElementById("emailid-error").style.display="block";
		}
        else if(emailid.value.indexOf('.')==-1)
        {
        	emailid.style.borderColor="red";
			document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
			document.getElementById("emailid-error").style.display="block";
		}

		else
		{
		emailid.style.borderColor=" #00CC00";
		document.getElementById("emailid-error").style.display="none";
		}
		}
 		
 		function validate_desig()
		{
		var desig=document.getElementById("desig");
		if(desig.value=="Select")
		{
			desig.style.borderColor="red";
			document.getElementById("desig-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
			document.getElementById("desig-error").style.display="block";
		}  
		else
		{
		desig.style.borderColor=" #00CC00";
		document.getElementById("desig-error").style.display="none";
		}
		}
 		function validatedist(){
 		
	var type=document.getElementById("dst");
		if(type.value=="Select")
		{
			type.style.borderColor="red";
			document.getElementById("dst-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
			document.getElementById("dst-error").style.display="block";
		}  
		else
		{
		type.style.borderColor=" #00CC00";
		document.getElementById("dst-error").style.display="none";
		}
		}

 		function validate_contact()
 		{	
 			var contactno=document.getElementById("contactno");
 				if(contactno.value=="Select")
 				{
 					contactno.style.borderColor="red";
 					document.getElementById("contactno-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Contact No </span>';
 					document.getElementById("contactno-error").style.display="block";
 				}  
 				else
 				{
 					contactno.style.borderColor=" #00CC00";
 				document.getElementById("contactno-error").style.display="none";
 				}
 				}

 		
 		function validate_statn()
		{
		var type=document.getElementById("pstn");
		if(type.value=="Select")
		{
			type.style.borderColor="red";
			document.getElementById("statn-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
			document.getElementById("statn-error").style.display="block";
		}  
		else
		{
		type.style.borderColor="#00CC00";
		document.getElementById("statn-error").style.display="none";
		}
		}
 		
 		
 		function validateform()
		{
			var kgid=document.getElementById("kgid");
			var name=document.getElementById("name");
			var pass=document.getElementById("password");
			var desig=document.getElementById("desig");
			var dst=document.getElementById("dst");
			var statn=document.getElementById("statn");
			var emailid=document.getElementById("emailid");
			if(kgid.value=="" || pass.value=="" || desig.value=="" || dst.value== "" || statn.value=="" || emailid.value=="" || name.value="")
			{
				document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
				document.getElementById("noway").style.display="block";
			}
			else
			{
		document.getElementById("noway").style.display="none";
		login();
			}
		}
	function login()
	{
		$('noway').style.display="block";
		$('noway').innerHTML='<img src="../image/8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
			new Ajax.Request( '../actions/see_add_officer.jsp',
			{
		method: 'post',
		postBody: $('logform').serialize(),
		onSuccess: function( transport ) {
			if( transport.responseText.match( /1/ ) )
		$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>Police Officer added Successfully!</b></span>';
		if( transport.responseText.match( /0/ ) )
			$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Problem while adding! Try Again.</b></span>';
		
		}
			} );
	}
