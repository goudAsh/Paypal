function captcha()
		{
		var randno=Math.round(1 + Math.random()*(5-1));
		if (randno==1)
		{
		document.getElementById("c-image").innerHTML='<img src="captcha-Images/1.bmp" height="50" width="150" /><input type="text" value="28ivw" name="image1" id="image1" style="visibility:hidden" />';
		}
		if (randno==2)
		{
		document.getElementById("c-image").innerHTML='<img src="captcha-Images/2.bmp" height="50" width="150"/><input type="text" value="k 4ez" name="image1" id="image1" style="visibility:hidden" />';
		}
		if (randno==3)
		{
		document.getElementById("c-image").innerHTML='<img src="captcha-Images/3.bmp" height="50" width="150" /><input type="text" value="HRAI" name="image1" id="image1" style="visibility:hidden" />';
		}
		if (randno==4)
		{
		document.getElementById("c-image").innerHTML='<img src="captcha-Images/4.bmp" height="50" width="150"/><input type="text" value="XDHYN" name="image1" id="image1" style="visibility:hidden" />';
		}
		if (randno==5)
		{
		document.getElementById("c-image").innerHTML='<img src="captcha-Images/5.bmp" height="50" width="150"/><input type="text" value="4D7YS" name="image1" id="image1" style="visibility:hidden" />';
		}
		
}
		