function validatename()
			{
			var name=document.getElementById("name");
			if(name.value=="")
			{
				name.style.borderColor="red";
				document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
				document.getElementById("name-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("name-error").style.display="none";
			}
			}
function validatefname()
{
var fname=document.getElementById("fname");
if(fname.value=="")
{
	fname.style.borderColor="red";
	document.getElementById("fname-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
	document.getElementById("fname-error").style.display="block";
}  
else
{
fname.style.borderColor=" #00CC00";
document.getElementById("fname-error").style.display="none";
}
}
function validatepob()
{
var pob=document.getElementById("pob");
if(pob.value=="")
{
	pob.style.borderColor="red";
	document.getElementById("pob-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Place of Birth cannot be blank</span>';
	document.getElementById("pob-error").style.display="block";
}  
else
{
	pob.style.borderColor=" #00CC00";
document.getElementById("pob-error").style.display="none";
}
}
function validatepaddress()
{
var paddress=document.getElementById("paddress");
if(paddress.value=="")
{
	paddress.style.borderColor="red";
	document.getElementById("paddress-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Present Address cannot be blank</span>';
	document.getElementById("paddress-error").style.display="block";
}  
else
{
	paddress.style.borderColor=" #00CC00";
document.getElementById("paddress-error").style.display="none";
}
}
function validateoffice()
{
var office=document.getElementById("office");
if(office.value=="")
{
	office.style.borderColor="red";
	document.getElementById("office-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Office number cannot be blank</span>';
	document.getElementById("office-error").style.display="block";
}  
else
{
	office.style.borderColor=" #00CC00";
document.getElementById("office-error").style.display="none";
}
}
function validatemobile()
{
var mobile=document.getElementById("mobile");
if(mobile.value=="")
{
	mobile.style.borderColor="red";
	document.getElementById("mobile-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Mobile number cannot be blank</span>';
	document.getElementById("mobile-error").style.display="block";
}  
else
{
	mobile.style.borderColor=" #00CC00";
document.getElementById("mobile-error").style.display="none";
}
}
function validateaddress()
{
var address=document.getElementById("address");
if(address.value=="")
{
	address.style.borderColor="red";
	document.getElementById("address-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Address cannot be blank</span>';
	document.getElementById("address-error").style.display="block";
}  
else
{
address.style.borderColor=" #00CC00";
document.getElementById("address-error").style.display="none";
}
}
function validateoccupation()
{
	var occupation=document.getElementById("occupation");
	if(occupation.value=="")
	{
		occupation.style.borderColor="red";
		document.getElementById("occupation-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Occupation cannot be blank</span>';
		document.getElementById("occupation-error").style.display="block";
	}  
	else
	{
		occupation.style.borderColor=" #00CC00";
	document.getElementById("occupation-error").style.display="none";
	}
	}
function validateneed()
{
	var need=document.getElementById("need");
	if(need.value=="")
	{
		need.style.borderColor="red";
		document.getElementById("need-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">This is required field</span>';
		document.getElementById("need-error").style.display="block";
	}  
	else
	{
		need.style.borderColor=" #00CC00";
	document.getElementById("need-error").style.display="none";
	}
	}
function validateclaim()
{
	var claim=document.getElementById("claim");
	if(claim.value=="")
	{
		claim.style.borderColor="red";
		document.getElementById("claim-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">This is required field</span>';
		document.getElementById("claim-error").style.display="block";
	}  
	else
	{
		claim.style.borderColor=" #00CC00";
	document.getElementById("claim-error").style.display="none";
	}
	}
function validatepassportno()
{
	var passportno=document.getElementById("passportno");
	if(passportno.value=="")
	{
		passportno.style.borderColor="red";
		document.getElementById("passportno-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Passport No. cannot be blank</span>';
		document.getElementById("passportno-error").style.display="block";
	}  
	else
	{
		passportno.style.borderColor=" #00CC00";
	document.getElementById("passportno-error").style.display="none";
	}
	}
function validateform()
{
	var username=document.getElementById("name");
	var fname=document.getElementById("fname");
	var pob=document.getElementById("pob");
	var paddress=document.getElementById("paddress");
	var office=document.getElementById("office");
	var address=document.getElementById("address");
	var mobile=document.getElementById("mobile");
	var occupation=document.getElementById("occupation");
	var need=document.getElementById("need");
	var claim=document.getElementById("claim");
	if(username.value=="" || fname.value=="" || pob.value=="" || paddress.value== "" || office.value=="" || address.value=="" || mobile.value=="" || occupation.value=="" || need.value=="" || claim.value=="" )
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	
	}
	else
		check();
}
function check()
{
	$('noway').innerHTML='<img src="image/8-0.gif" /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-size:14;">PLEASE WAIT!</span>';
		new Ajax.Request( 'actions/see-arm.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
			if( transport.responseText.match( /1/ ) )
			{
				$('noway').style.display="block";
				$('noway').innerHTML='<span style="margin-left:10; text-align:center; font-family:Arial; font-size:16; color:green"><b>THANK YOU..!! We received your license request. Check your mail box for more details.</b></span>';
			}
			else if( transport.responseText.match( /0/ ) )
    			{		
  				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>You have already applied for this license! Please wait for our response.</b></span>';
  				$('noway').style.display="block";
    			}
			else
			{
				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>Problem while we receiving you request!! Try later.</b></span>';
  				$('noway').style.display="block";
			}
			}
		} );
}