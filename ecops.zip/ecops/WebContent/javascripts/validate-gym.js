function validatename()
			{
			var name=document.getElementById("name");
			if(name.value=="")
			{
				name.style.borderColor="red";
				document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
				document.getElementById("name-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("name-error").style.display="none";
			}
			}
function validateaddress()
{
var address=document.getElementById("address");
if(address.value=="")
{
	address.style.borderColor="red";
	document.getElementById("address-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Address cannot be blank</span>';
	document.getElementById("address-error").style.display="block";
}  
else
{
address.style.borderColor=" #00CC00";
document.getElementById("address-error").style.display="none";
}
}
function validateduration()
{
var duration=document.getElementById("duration");
if(duration.value=="")
{
	duration.style.borderColor="red";
	document.getElementById("duration-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Duration cannot be blank</span>';
	document.getElementById("duration-error").style.display="block";
}  
else
{
	duration.style.borderColor=" #00CC00";
document.getElementById("duration-error").style.display="none";
}
}
function validatepincode()
{
var pincode=document.getElementById("pincode");
if(pincode.value=="")
{
	pincode.style.borderColor="red";
	document.getElementById("pincode-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Pincode cannot be blank</span>';
	document.getElementById("pincode-error").style.display="block";
}  
else
{
pincode.style.borderColor=" #00CC00";
document.getElementById("pincode-error").style.display="none";
}
}
function validatearea()
{
var area=document.getElementById("area");
if(area.value=="")
{
	area.style.borderColor="red";
	document.getElementById("area-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Area cannot be blank</span>';
	document.getElementById("area-error").style.display="block";
}  
else
{
area.style.borderColor=" #00CC00";
document.getElementById("area-error").style.display="none";
}
}
function validatecity()
{
var city=document.getElementById("city");
if(city.value=="")
{
	city.style.borderColor="red";
	document.getElementById("city-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">City cannot be blank</span>';
	document.getElementById("city-error").style.display="block";
}  
else
{
	city.style.borderColor=" #00CC00";
document.getElementById("city-error").style.display="none";
}
}

function validatebarea()
{
var barea=document.getElementById("b-area");
if(barea.value=="")
{
	barea.style.borderColor="red";
	document.getElementById("b-area-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">This is required field</span>';
	document.getElementById("b-area-error").style.display="block";
}  
else
{
barea.style.borderColor=" #00CC00";
document.getElementById("b-area-error").style.display="none";
}
}
function validateform()
{
	var username=document.getElementById("name");
	var pincode=document.getElementById("pincode");
	var address=document.getElementById("address");
	var area=document.getElementById("area");
	var barea=document.getElementById("b-area");
	var duration=document.getElementById("duration");
	if(username.value=="" || pincode.value=="" || barea.value== "" ||  address.value=="" || area.value=="" || duration.value=="")
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	
	}
	else
		check();
}
function check()
{
	$('noway').innerHTML='<img src="image/8-0.gif" /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-size:14;">PLEASE WAIT!</span>';
		new Ajax.Request( 'actions/see-gym.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
			if( transport.responseText.match( /1/ ) )
			{
				$('noway').style.display="block";
				$('noway').innerHTML='<span style="margin-left:10; text-align:center; font-family:Arial; font-size:16; color:green"><b>THANK YOU..!! We received your license request. Check your mail box for more details.</b></span>';
			}
			else if( transport.responseText.match( /0/ ) )
    			{		
  				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>You have already applied for this license! Please wait for our response.</b></span>';
  				$('noway').style.display="block";
    			}
			else
			{
				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>Problem while we receiving you request!! Try later.</b></span>';
  				$('noway').style.display="block";
			}
			}
		} );
}