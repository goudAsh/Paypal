function validate_dst()
		{
		var type=document.getElementById("dst");
		if(type.value=="Select")
		{
			type.style.borderColor="red";
			document.getElementById("dst-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
			document.getElementById("dst-error").style.display="block";
		}  
		else
		{
		type.style.borderColor=" #00CC00";
		document.getElementById("dst-error").style.display="none";
		}
		}

function validate_fir()
{
var type=document.getElementById("fir");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("fir-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("fir-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("fir-error").style.display="none";
}
}

 		
 		function validate_statn()
		{
		var type=document.getElementById("statn");
		if(type.value=="Select")
		{
			type.style.borderColor="red";
			document.getElementById("statn-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
			document.getElementById("statn-error").style.display="block";
		}  
		else
		{
		type.style.borderColor=" #00CC00";
		document.getElementById("statn-error").style.display="none";
		}
		}
 		
 		function validate_kgid()
		{
		var name=document.getElementById("KGID");
		if(name.value=="")
		{
			name.style.borderColor="red";
			document.getElementById("kgid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">KGID cannot be blank</span>';
			document.getElementById("kgid-error").style.display="block";
		}  
		else
		{
		name.style.borderColor=" #00CC00";
		document.getElementById("kgid-error").style.display="none";
		}
		}
 		
 		function validate_code()
		{
		var code=document.getElementById("code");
		if(code.value=="")
		{
			code.style.borderColor="red";
			document.getElementById("code-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Court code cannot be blank</span>';
			document.getElementById("code-error").style.display="block";
		}  
		else
		{
			code.style.borderColor=" #00CC00";
		document.getElementById("code-error").style.display="none";
		}
		}
 		

 		 function validate_Csheet()
		{
		var Csheet=document.getElementById("Csheet");
		if(Csheet.value=="")
		{
			Csheet.style.borderColor="red";
			document.getElementById("Csheet-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Charge Sheet no cannot be blank</span>';
			document.getElementById("Csheet-error").style.display="block";
		}  
		else
		{
			Csheet.style.borderColor=" #00CC00";
		document.getElementById("Csheet-error").style.display="none";
		}
		}
 	
 		
 		
 		
 		
 		function validate_name()
		{
		var name=document.getElementById("name");
		if(name.value=="")
		{
			name.style.borderColor="red";
			document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
			document.getElementById("name-error").style.display="block";
		}  
		else
		{
		name.style.borderColor=" #00CC00";
		document.getElementById("name-error").style.display="none";
		}
		}
 		

 		function validate_fmname()
		{
		var fmname=document.getElementById("fmname");
		if(fmname.value=="")
		{
			fmname.style.borderColor="red";
			document.getElementById("fmname-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
			document.getElementById("fmname-error").style.display="block";
		}  
		else
		{
			fmname.style.borderColor=" #00CC00";
		document.getElementById("fmname-error").style.display="none";
		}
		}
 		
 		function validate_occu()
		{
		var occu=document.getElementById("occu");
		if(occu.value=="")
		{
			occu.style.borderColor="red";
			document.getElementById("occu-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
			document.getElementById("occu-error").style.display="block";
		}  
		else
		{
			occu.style.borderColor=" #00CC00";
		document.getElementById("occu-error").style.display="none";
		}
		}
 		
 		
 		
 		function validate_nation()
		{
		var nation=document.getElementById("nation");
		if(nation.value=="Select")
		{
			nation.style.borderColor="red";
			document.getElementById("other-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
			document.getElementById("other-error").style.display="block";
		}  
		else
		{
			nation.style.borderColor=" #00CC00";
		document.getElementById("other-error").style.display="none";
		}
		}
 		
 		function validate_wit()
		{
		var wit1=document.getElementById("wit_name1");
		if(wit1.value=="")
		{
			wit1.style.borderColor="red";
			document.getElementById("wit-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
			document.getElementById("wit-error").style.display="block";
		}  
		else
		{
		wit1.style.borderColor=" #00CC00";
		document.getElementById("wit-error").style.display="none";
		}
		}
 		
 		function validate_add1()
		{
		var add1=document.getElementById("add1");
		if(add1.value=="")
		{
			add1.style.borderColor="red";
			document.getElementById("add1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Address cannot be blank</span>';
			document.getElementById("add1-error").style.display="block";
		}  
		else
		{
		add1.style.borderColor= "#00CC00";
		document.getElementById("add1-error").style.display="none";
		}
	}
 		
 		function validateform()
		{
 				
 			var kgid=document.getElementById("kgid");
			var fir=document.getElementById("fir");
			var code=document.getElementById("code");
			var dst=document.getElementById("dst");
			var statn=document.getElementById("statn");
			var Csheet=document.getElementById("Csheet");
			var name=document.getElementById("name");
			
			var gender=document.getElementById("gender");
			var fmname=document.getElementById("fmname");
			var nation=document.getElementById("nation");
			var occu=document.getElementById("occu");
			
			var wit_name=document.getElementById("wit_name1");
			var add1=document.getElementById("add1");
			
			if(name.value=="" || fir.value=="Select" || dst.value=="Select" || statn.value== "Select" || kgid.value=="" || code.value=="" || nation.value== "Select" || name.value=="" || occu.value=="" || add1.value=="" || wit_name.value=="" || fmname.value=="" ||Csheet.value=="")
			{
			document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
			document.getElementById("noway").style.display="block";
			
			}
			else
				login();
		}
 		
 		function login()
 		{   
 			$('noway').style.display="block";
 			$('noway').innerHTML='<b style="font-size:14;"> Please Wait!</b>';
 				new Ajax.Request( '../actions/see_finalreport.jsp',
 				{
 			method: 'post',
 			postBody: $('logform').serialize(),
 			onSuccess: function( transport ) {
 				if( transport.responseText.match( /1/ ) )
 			$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>Final report updated successfully!!!</b></span>';
 			if( transport.responseText.match( /0/ ) )
 				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Problem while updating Final Report!!try again..!!</b></span>';
 			
 			}
 				} );
 		}	
 		
 		
 		
 		
 		
 		
 		