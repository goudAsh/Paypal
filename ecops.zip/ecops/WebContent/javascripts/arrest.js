function validatefir()
			{
			var firno=document.getElementById("firno");
			if(firno.value=="")
			{
				firno.style.borderColor="red";
				document.getElementById("firno-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">FIR No cannot be blank</span>';
				document.getElementById("firno-error").style.display="block";
			}
			
			else
			{
			firno.style.borderColor=" #00CC00";
			document.getElementById("firno-error").style.display="none";
			}
			}

function validatedate()
{
var date=document.getElementById("date");
if(date.value=="")
{
	date.style.borderColor="red";
	document.getElementById("date-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Date cannot be blank</span>';
	document.getElementById("date-error").style.display="block";
}  
else
{
date.style.borderColor=" #00CC00";
document.getElementById("date-error").style.display="none";
}
}		

function validatedate1()
{
var date1=document.getElementById("date1");
if(date1.value=="")
{
	date1.style.borderColor="red";
	document.getElementById("date1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Date cannot be blank</span>';
	document.getElementById("date1-error").style.display="block";
}  
else
{
date1.style.borderColor=" #00CC00";
document.getElementById("date1-error").style.display="none";
}
}		

function validatedate2()
{
var date2=document.getElementById("date2");
if(date2.value=="")
{
	date2.style.borderColor="red";
	document.getElementById("date2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Date cannot be blank</span>';
	document.getElementById("date2-error").style.display="block";
}  
else
{
date.style.borderColor=" #00CC00";
document.getElementById("date2-error").style.display="none";
}
}		


function validatedistrict()
{
var district=document.getElementById("district");
if(district.value=="")
{
	district.style.borderColor="red";
	document.getElementById("district-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the District</span>';
	document.getElementById("district-error").style.display="block";
}  
else
{
	district.style.borderColor=" #00CC00";
document.getElementById("date-error").style.display="none";
}
}

function validatestreet()
{
var street=document.getElementById("street");
if(street.value=="")
{
	street.style.borderColor="red";
	document.getElementById("street-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Street</span>';
	document.getElementById("street-error").style.display="block";
}  
else
{
	street.style.borderColor=" #00CC00";
document.getElementById("street-error").style.display="none";
}
}

function validatearea()
{
var area=document.getElementById("area");
if(area.value=="")
{
	area.style.borderColor="red";
	document.getElementById("area-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Area</span>';
	document.getElementById("area-error").style.display="block";
}  
else
{
	area.style.borderColor=" #00CC00";
document.getElementById("area-error").style.display="none";
}
}

function validatecity()
{
var city=document.getElementById("city");
if(city.value=="")
{
	city.style.borderColor="red";
	document.getElementById("city-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the City</span>';
	document.getElementById("city-error").style.display="block";
}  
else
{
	city.style.borderColor=" #00CC00";
document.getElementById("city-error").style.display="none";
}
}

function validatestate2()
{
var state2=document.getElementById("state2");
if(state2.value=="")
{
	state2.style.borderColor="red";
	document.getElementById("state2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the State</span>';
	document.getElementById("state2-error").style.display="block";
}  
else
{
	state2.style.borderColor=" #00CC00";
    document.getElementById("state2-error").style.display="none";
}
}


function validateoccup()
{
var occupation=document.getElementById("occupation");
if(occupation.value=="")
{
	occupation.style.borderColor="red";
	document.getElementById("occupation-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Occupation</span>';
	document.getElementById("occupation-error").style.display="block";
}  
else
{
	occupation.style.borderColor=" #00CC00";
document.getElementById("occupation-error").style.display="none";
}
}


function validatelang()
{
var lang=document.getElementById("lang");
if(lang.value=="")
{
	lang.style.borderColor="red";
	document.getElementById("lang-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Languages</span>';
	document.getElementById("lang-error").style.display="block";
}  
else
{
	lang.style.borderColor=" #00CC00";
document.getElementById("lang-error").style.display="none";
}
}


function validatehgt()
{
var hgt=document.getElementById("hgt");
if(hgt.value=="")
{
	hgt.style.borderColor="red";
	document.getElementById("hgt-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Height</span>';
	document.getElementById("hgt-error").style.display="block";
}  
else
{
	hgt.style.borderColor=" #00CC00";
document.getElementById("hgt-error").style.display="none";
}
}

function validatecondition()
{
var condition=document.getElementById("condition");
if(condition.value=="")
{
	condition.style.borderColor="red";
	document.getElementById("condition-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Physical Condition</span>';
	document.getElementById("condition-error").style.display="block";
}  
else
{
	condition.style.borderColor=" #00CC00";
document.getElementById("condition-error").style.display="none";
}
}


function validatestate1()
{
var state1=document.getElementById("state1");
if(state1.value=="")
{
	state1.style.borderColor="red";
	document.getElementById("state1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the State</span>';
	document.getElementById("state1-error").style.display="block";
}  
else
{
	state1.style.borderColor=" #00CC00";
    document.getElementById("state1-error").style.display="none";
}
}


function save()
{
	var firno=document.getElementById("firno");
	//var date=document.getElementById("date");
	//var date1=document.getElementById("date1");
	//var state1=document.getElementById("state1");
	//var date2=document.getElementById("date2");
	//var occupation=document.getElementById("occupation");
	//var lang=document.getElementById("lang");
	//var district=document.getElementById("district");
	//var pstn=document.getElementById("pstn");
	//var nation=document.getElementById("nation");
	//var addr2=document.getElementById("addr2");
	//var hgt=document.getElementById("hgt");
	//var phycond=document.getElementById("condition");
	
	if(firno.value==" ")
	{
	document.getElementById("save-error").innerHTML='<br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("save-error").style.display="block";
	}
	else
	{
		document.getElementById("save-error").style.display="none";
		save1();
	}
}
function save1()
{
document.getElementById("addbutton").disabled="";
$('save-error').style.display="block";
$('save-error').innerHTML='<span style="margin-left:200;"><img src="../image/8-0.gif" /><b style="font-size:14;"> Please Wait!</b></span>';
	new Ajax.Request( '../actions/see_arrestinfo.jsp',
	{
method: 'post',
postBody: $('logform').serialize(),
onSuccess: function( transport ) {
	if( transport.responseText.match( /1/ ) )
$('save-error').innerHTML='<span style="margin-left:300; font-family:Arial; font-size:14; color:green"><b>Arrest/Surrender Details saved..!!</b></span><br/><span style="margin-left:250; font-family:Arial; font-size:14;"><b>To add another person click on <span style="color:green">Add Person</span> button</b></span>';
if( transport.responseText.match( /0/ ) )
	$('save-error').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Failed to save..! Try again</b></span>';
}
	} );	
}



