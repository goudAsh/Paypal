function validatename()
			{
			var name=document.getElementById("name");
			if(name.value=="")
			{
				name.style.borderColor="red";
				document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
				document.getElementById("name-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("name-error").style.display="none";
			}
			}
function validatesubject()
{
	var subject=document.getElementById("subject");
	if(subject.value=="")
	{
		subject.style.borderColor="red";
		document.getElementById("subject-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Subject cannot be blank</span>';
		document.getElementById("subject-error").style.display="block";
	}  
else
	{
		subject.style.borderColor=" #00CC00";
		document.getElementById("subject-error").style.display="none";
	}
}
function validatecontent()
{
	var content=document.getElementById("contents");
	if(content.value=="")
	{
		content.style.borderColor="red";
		document.getElementById("content-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Content cannot be blank</span>';
		document.getElementById("content-error").style.display="block";
	}  
else
	{
		content.style.borderColor="#00CC00";
		document.getElementById("content-error").style.display="none";
	}
}
function validateemailid()
{
var emailid=document.getElementById("emailid");
if(emailid.value=="")
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot be blank</span>';
	document.getElementById("emailid-error").style.display="block";
} 
else if(emailid.value.indexOf(' ')>=0)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot have blank space</span>';
	document.getElementById("emailid-error").style.display="block";
}
else if(emailid.value.indexOf('@')==-1)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
	document.getElementById("emailid-error").style.display="block";
}
else if(emailid.value.indexOf('.')==-1)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
	document.getElementById("emailid-error").style.display="block";
}

else
{
emailid.style.borderColor=" #00CC00";
document.getElementById("emailid-error").style.display="none";
}
}
function validateform()
{
	var username=document.getElementById("name");
	var subject=document.getElementById("subject");
	var content=document.getElementById("contents");
	var emailid=document.getElementById("emailid");
	if(username.value=="" ||subject.value=="" || content.value=="" || emailid.value=="")
	{
	document.getElementById("form-error").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("form-error").style.display="block";
	
	}
	else
	{
		check();
	}
	}
function check()
{
	$('form-error').innerHTML='<img src="image/8-0.gif" /><span style="font-size:14;">PLEASE WAIT!</span>';
		new Ajax.Request( 'actions/see-feedback.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
			if( transport.responseText.match( /1/ ) )
			{
				$('form-error').style.display="block";
				$('form-error').innerHTML='<span style="margin-left:10; text-align:center; font-family:Arial; font-size:16; color:green"><b>THANK YOU..!! We received your Feedback.</b></span>';
			}
    			if( transport.responseText.match( /0/ ) )
    			{		
  				$('form-error').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>Problem while receiving your Feedback. Please try later!</b></span>';
  				$('form-error').style.display="block";
    			}
    			}
		} );
}
