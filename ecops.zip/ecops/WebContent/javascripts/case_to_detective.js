function validate_kgid()
			{
			var name=document.getElementById("kgid");
			if(name.value=="Select")
			{
				name.style.borderColor="red";
				document.getElementById("kgid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">KGID cannot be blank</span>';
				document.getElementById("kgid-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("kgid-error").style.display="none";
			}
			}

function validate_fir()
{
var type=document.getElementById("fir");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("fir-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("fir-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("fir-error").style.display="none";
}
}


function validate_name()
{
var off_name=document.getElementById("dtname");
if(off_name.value=="")
{
	off_name.style.borderColor="red";
	document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
	document.getElementById("name-error").style.display="block";
}  
else
{
off_name.style.borderColor=" #00CC00";
document.getElementById("name-error").style.display="none";
}
}

function validateform()
{

	var kgid=document.getElementById("kgid");

	var name=document.getElementById("dtname");
	var fir=document.getElementById("fir");
	
	if( kgid.value=="Select" || fir.value== " " || name.value==" ")
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	
	}
	else
		login();
	
}

function login()
{   
	$('noway').style.display="block";
	$('noway').innerHTML='<img src="../8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
		new Ajax.Request( '../actions/see_assign_dt.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
		if( transport.responseText.match( /1/ ) )
	$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>New case assigned to detective successfully!!!</b></span>';
	if( transport.responseText.match( /0/ ) )
		$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Problem while assigning case!!try again..!!</b></span>';
	
	}
		} );
}	




