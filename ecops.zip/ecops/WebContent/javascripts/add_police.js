function validate_kgid()
			{
			var name=document.getElementById("KGID");
			if(name.value=="")
			{
				name.style.borderColor="red";
				document.getElementById("kgid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">KGID cannot be blank</span>';
				document.getElementById("kgid-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("kgid-error").style.display="none";
			}
			}

 		function validate_password()
 		{
 			var name=document.getElementById("password");
 			if(name.value=="")
 			{
 				name.style.borderColor="red";
 				document.getElementById("pass-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">password cannot be blank</span>';
 				document.getElementById("pass-error").style.display="block";
 			}  
 			else
 			{
 				name.style.borderColor=" #00CC00";
 				document.getElementById("pass-error").style.display="none";
 			}
 		}
 		
 		function validate_email()
		{
		var emailid=document.getElementById("email-id");
		if(emailid.value=="")
		{
			emailid.style.borderColor="red";
			document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot be blank</span>';
			document.getElementById("emailid-error").style.display="block";
		} 
		else if(emailid.value.indexOf(' ')>=0)
		{
			emailid.style.borderColor="red";
			document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot have blank space</span>';
			document.getElementById("emailid-error").style.display="block";
		}
        else if(emailid.value.indexOf('@')==-1)
        {
        	emailid.style.borderColor="red";
			document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
			document.getElementById("emailid-error").style.display="block";
		}
        else if(emailid.value.indexOf('.')==-1)
        {
        	emailid.style.borderColor="red";
			document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
			document.getElementById("emailid-error").style.display="block";
		}

		else
		{
		emailid.style.borderColor=" #00CC00";
		document.getElementById("emailid-error").style.display="none";
		}
		}
 		
 		function validate_desig()
		{
		var desig=document.getElementById("desig");
		if(desig.value=="Select")
		{
			desig.style.borderColor="red";
			document.getElementById("desig-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
			document.getElementById("desig-error").style.display="block";
		}  
		else
		{
		desig.style.borderColor=" #00CC00";
		document.getElementById("desig-error").style.display="none";
		}
		}
 		
 		
 	
		
 		
 		function validate_dst()
		{
		var type=document.getElementById("dst");
		if(type.value=="Select")
		{
			type.style.borderColor="red";
			document.getElementById("dst-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
			document.getElementById("dst-error").style.display="block";
		}  
		else
		{
		type.style.borderColor=" #00CC00";
		document.getElementById("dst-error").style.display="none";
		}
		}
 		
 		function validate_statn()
		{
		var type=document.getElementById("statn");
		if(type.value=="Select")
		{
			type.style.borderColor="red";
			document.getElementById("statn-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
			document.getElementById("statn-error").style.display="block";
		}  
		else
		{
		type.style.borderColor=" #00CC00";
		document.getElementById("statn-error").style.display="none";
		}
		}
 		
 		
 		function validateform()
		{
			var kgid=document.getElementById("KGID");
			var pass=document.getElementById("password");
			var desig=document.getElementById("desig");
			var dst=document.getElementById("dst");
			var statn=document.getElementById("statn");
			var emailid=document.getElementById("emailid");
			if(kgid.value=="" || pass.value=="" || desig.value=="" || dst.value== "" || statn.value=="" || emailid.value=="")
			{
			document.getElementById("form-error").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
			document.getElementById("form-error").style.display="block";
			return false;
			}
			else
			return true;
		}
 		