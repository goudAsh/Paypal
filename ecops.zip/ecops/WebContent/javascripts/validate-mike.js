function validatename()
			{
			var name=document.getElementById("name");
			if(name.value=="")
			{
				name.style.borderColor="red";
				document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
				document.getElementById("name-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("name-error").style.display="none";
			}
			}
function validatestime()
{
var stime=document.getElementById("stime");
if(stime.value=="")
{
	stime.style.borderColor="red";
	document.getElementById("stime-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Start Time cannot be blank</span>';
	document.getElementById("stime-error").style.display="block";
}  
else
{
	stime.style.borderColor=" #00CC00";
document.getElementById("stime-error").style.display="none";
}
}
function validateetime()
{
var etime=document.getElementById("etime");
if(etime.value=="")
{
	etime.style.borderColor="red";
	document.getElementById("etime-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">End TIme cannot be blank</span>';
	document.getElementById("etime-error").style.display="block";
}  
else
{
	etime.style.borderColor=" #00CC00";
document.getElementById("etime-error").style.display="none";
}
}

function validatepresent()
{
var present=document.getElementById("present");
if(present.value=="")
{
	present.style.borderColor="red";
	document.getElementById("present-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Present address cannot be blank</span>';
	document.getElementById("present-error").style.display="block";
}  
else
{
	present.style.borderColor=" #00CC00";
document.getElementById("present-error").style.display="none";
}
}
function validateoffice()
{
var office=document.getElementById("office");
if(office.value=="")
{
	office.style.borderColor="red";
	document.getElementById("office-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Office number cannot be blank</span>';
	document.getElementById("office-error").style.display="block";
}  
else
{
	office.style.borderColor=" #00CC00";
document.getElementById("office-error").style.display="none";
}
}
function validatemobile()
{
var mobile=document.getElementById("mobile");
if(mobile.value=="")
{
	mobile.style.borderColor="red";
	document.getElementById("mobile-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Mobile number cannot be blank</span>';
	document.getElementById("mobile-error").style.display="block";
}  
else
{
	mobile.style.borderColor=" #00CC00";
document.getElementById("mobile-error").style.display="none";
}
}
function validateorganisation()
{
var organisation=document.getElementById("organisation");
if(organisation.value=="")
{
	organisation.style.borderColor="red";
	document.getElementById("organisation-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Organisation name cannot be blank</span>';
	document.getElementById("organisation-error").style.display="block";
}  
else
{
	organisation.style.borderColor=" #00CC00";
document.getElementById("organisation-error").style.display="none";
}
}
function validateaddress()
{
var address=document.getElementById("address");
if(address.value=="")
{
	address.style.borderColor="red";
	document.getElementById("address-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Address cannot be blank</span>';
	document.getElementById("address-error").style.display="block";
}  
else
{
address.style.borderColor=" #00CC00";
document.getElementById("address-error").style.display="none";
}
}
function validateno()
{
var no=document.getElementById("no");
if(no.value=="")
{
	no.style.borderColor="red";
	document.getElementById("no-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Contact No. cannot be blank</span>';
	document.getElementById("no-error").style.display="block";
}  
else
{
	no.style.borderColor=" #00CC00";
document.getElementById("no-error").style.display="none";
}
}
function validateevent()
{
var event=document.getElementById("event");
if(event.value=="")
{
	event.style.borderColor="red";
	document.getElementById("event-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Nature of Event cannot be blank</span>';
	document.getElementById("event-error").style.display="block";
}  
else
{
	event.style.borderColor=" #00CC00";
document.getElementById("event-error").style.display="none";
}
}
function validatelocation()
{
var location=document.getElementById("location");
if(location.value=="")
{
	location.style.borderColor="red";
	document.getElementById("location-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Location cannot be blank</span>';
	document.getElementById("location-error").style.display="block";
}  
else
{
location.style.borderColor=" #00CC00";
document.getElementById("location-error").style.display="none";
}
}
function validateduration()
{
var duration=document.getElementById("duration");
if(duration.value=="")
{
	duration.style.borderColor="red";
	document.getElementById("duration-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Duration cannot be blank</span>';
	document.getElementById("duration-error").style.display="block";
}  
else
{
	duration.style.borderColor=" #00CC00";
document.getElementById("duration-error").style.display="none";
}
}
function validateform()
{
	var username=document.getElementById("name");
	var present=document.getElementById("present");
	var office=document.getElementById("office");
	var mobile=document.getElementById("mobile");
	var organisation=document.getElementById("organisation");
	var address=document.getElementById("address");
	var no=document.getElementById("no");
	var event=document.getElementById("event");
	var location=document.getElementById("location");
	var duration=document.getElementById("duration");
	var stime=document.getElementById("stime");
	var etime=document.getElementById("etime");
	if(username.value=="" || present.value=="" || office.value==""|| stime.value==""|| etime.value=="" || mobile.value== "" || organisation.value=="" || address.value=="" || no.value=="" || event.value=="" || location.value=="" || duration.value=="")
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	}
	else
	check();
}
function check()
{
	$('noway').innerHTML='<img src="image/8-0.gif" /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-size:14;">PLEASE WAIT!</span>';
		new Ajax.Request( 'actions/see-mike.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
			if( transport.responseText.match( /1/ ) )
			{
				$('noway').style.display="block";
				$('noway').innerHTML='<span style="margin-left:10; text-align:center; font-family:Arial; font-size:16; color:green"><b>THANK YOU..!! We received your license request. Check your mail box for more details.</b></span>';
			}
			else if( transport.responseText.match( /0/ ) )
    			{		
  				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>You have already applied for this license! Please wait for our response.</b></span>';
  				$('noway').style.display="block";
    			}
			else
			{
				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>Problem while we receiving you request!! Try later.</b></span>';
  				$('noway').style.display="block";
			}
			}
		} );
}