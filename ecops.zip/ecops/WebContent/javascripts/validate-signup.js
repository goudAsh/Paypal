			function validatename()
			{
			var name=document.getElementById("name");
			if(name.value=="")
			{
				name.style.borderColor="red";
				document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
				document.getElementById("name-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("name-error").style.display="none";
			}
			}
			function checkcaptcha()
			{
			var image1=document.getElementById("image1");
			var ctb=document.getElementById("captcha-tb");
			if(image1.value!=ctb.value)
			{
				ctb.style.borderColor="red";
				document.getElementById("ctb-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Incorrect Text! Try again.</span>';
				document.getElementById("ctb-error").style.display="block";
			}  
			else
			{
			ctb.style.borderColor=" #00CC00";
			document.getElementById("ctb-error").style.display="none";
			}
			}
			function validatepwdcheck()
			{
				var p1=document.getElementById("pwd");
				var p2=document.getElementById("cpwd");
				if(p1.value!=p2.value)
			{
					p1.style.borderColor="red";
					p2.style.borderColor="red";
				document.getElementById("cpwd-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Password not matching.Please re-enter!</span>';
				document.getElementById("cpwd-error").style.display="block";
			}  
			else
			{
			cpwd.style.borderColor=" #00CC00";
			document.getElementById("cpwd-error").style.display="none";
			}
			}
			function validatepwd()
			{
			var pwd=document.getElementById("pwd");
			if(pwd.value=="")
			{
				pwd.style.borderColor="red";
				document.getElementById("pwd-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Password cannot be blank</span>';
				document.getElementById("pwd-error").style.display="block";
			}  
			else
			{
			pwd.style.borderColor=" #00CC00";
			document.getElementById("pwd-error").style.display="none";
			}
			}
			function validatecpwd()
			{
			var cpwd=document.getElementById("cpwd");
			if(cpwd.value=="")
			{
				cpwd.style.borderColor="red";
				document.getElementById("cpwd-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please Re-Confirm the password</span>';
				document.getElementById("cpwd-error").style.display="block";
			}  
			else
			{
			cpwd.style.borderColor=" #00CC00";
			document.getElementById("cpwd-error").style.display="none";
			}
			}
			function validateaddress()
			{
			var address=document.getElementById("address");
			if(address.value=="")
			{
				address.style.borderColor="red";
				document.getElementById("address-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Address cannot be blank</span>';
				document.getElementById("address-error").style.display="block";
			}  
			else
			{
			address.style.borderColor=" #00CC00";
			document.getElementById("address-error").style.display="none";
			}
			}
			function validatecity()
			{
			var city=document.getElementById("city");
			if(city.value=="")
			{
				city.style.borderColor="red";
				document.getElementById("city-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">City cannot be blank</span>';
				document.getElementById("city-error").style.display="block";
			}  
			else
			{
			city.style.borderColor=" #00CC00";
			document.getElementById("city-error").style.display="none";
			}
			}
			function validatemob()
			{
			var mob=document.getElementById("mob");
			if(mob.value=="")
			{
				mob.style.borderColor="red";
				document.getElementById("mob-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Mobile Number cannot be blank</span>';
				document.getElementById("mob-error").style.display="block";
			}  
			else
			{
			mob.style.borderColor=" #00CC00";
			document.getElementById("mob-error").style.display="none";
			}
			}
			function validateproof()
			{
			var type=document.getElementById("type");
			if(type.value=="0")
			{
				type.style.borderColor="red";
				document.getElementById("type-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Proof submission is must! Please select the type of Proof.</span>';
				document.getElementById("type-error").style.display="block";
			}  
			else
			{
			type.style.borderColor=" #00CC00";
			document.getElementById("type-error").style.display="none";
			}
			}
			function validateno()
			{
			var no=document.getElementById("no");
			if(no.value=="")
			{
				no.style.borderColor="red";
				document.getElementById("no-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Document No. is must!</span>';
				document.getElementById("no-error").style.display="block";
			}  
			else
			{
			no.style.borderColor=" #00CC00";
			document.getElementById("no-error").style.display="none";
			}
			}
			function validateemail()
			{
			var emailid=document.getElementById("emailid");
			if(emailid.value=="")
			{
				emailid.style.borderColor="red";
				document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot be blank</span>';
				document.getElementById("emailid-error").style.display="block";
			} 
			else if(emailid.value.indexOf(' ')>=0)
			{
				emailid.style.borderColor="red";
				document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot have blank space</span>';
				document.getElementById("emailid-error").style.display="block";
			}
	        else if(emailid.value.indexOf('@')==-1)
	        {
	        	emailid.style.borderColor="red";
				document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
				document.getElementById("emailid-error").style.display="block";
			}
	        else if(emailid.value.indexOf('.')==-1)
	        {
	        	emailid.style.borderColor="red";
				document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
				document.getElementById("emailid-error").style.display="block";
			}

			else
			{
			emailid.style.borderColor=" #00CC00";
			document.getElementById("emailid-error").style.display="none";
			}
			}

			function validateform()
			{
				var username=document.getElementById("name");
				var address=document.getElementById("address");
				var city=document.getElementById("city");
				var mob=document.getElementById("mob");
				var type=document.getElementById("type");
				var pwd=document.getElementById("pwd");
				var cpwd=document.getElementById("cpwd");
				var emailid=document.getElementById("emailid");
				var file=document.getElementById("file");
				var ctb=document.getElementById("captcha-tb");
				var no=document.getElementById("no");
				if(username.value=="" || pwd.value=="" || no.value==""|| file.value==""|| ctb.value=="" ||cpwd.value==""|| address.value=="" || city.value=="" || mob.value== "" || type.value=="" || emailid.value=="")
				{
				document.getElementById("form-error").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
				document.getElementById("form-error").style.display="block";
				return false;
				}
				else
				return true;
			}