function validatefir()
			{
			var fir=document.getElementById("fir");
			if(fir.value=="")
			{
				fir.style.borderColor="red";
				document.getElementById("fir-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">FIR cannot be blank</span>';
				document.getElementById("fir-error").style.display="block";
			}  
			else
			{
			fir.style.borderColor=" #00CC00";
			document.getElementById("fir-error").style.display="none";
			}
			}

function validateaction()
{
var action=document.getElementById("action");
if(action.value=="")
{
	action.style.borderColor="red";
	document.getElementById("action-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Action Performed</span>';
	document.getElementById("action-error").style.display="block";
}  
else
{
	action.style.borderColor=" #00CC00";
document.getElementById("action-error").style.display="none";
}
}

function validateinfer()
{
var infer =document.getElementById("infer");
if(infer.value=="")
{
	infer.style.borderColor="red";
	document.getElementById("infer-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Inference</span>';
	document.getElementById("infer-error").style.display="block";
}  
else
{
	infer.style.borderColor=" #00CC00";
document.getElementById("infer-error").style.display="none";
}
}


function validatename()
{
var name =document.getElementById("name");
if(name.value=="")
{
	name.style.borderColor="red";
	document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Name</span>';
	document.getElementById("name-error").style.display="block";
}  
else
{
	name.style.borderColor=" #00CC00";
document.getElementById("name-error").style.display="none";
}
}


function validateaddress()
{
var address =document.getElementById("address");
if(address.value=="")
{
	address.style.borderColor="red";
	document.getElementById("address-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Address</span>';
	document.getElementById("address-error").style.display="block";
}  
else
{
	address.style.borderColor=" #00CC00";
document.getElementById("address-error").style.display="none";
}
}

function validateoccupation()
{
var occupation =document.getElementById("occupation");
if(occupation.value=="")
{
	occupation.style.borderColor="red";
	document.getElementById("occupation-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Occupation</span>';
	document.getElementById("occupation-error").style.display="block";
}  
else
{
	occupation.style.borderColor=" #00CC00";
document.getElementById("occupation-error").style.display="none";
}
}



function validateform()
{
		
	var fir=document.getElementById("fir");
	var action=document.getElementById("action");
	var infer=document.getElementById("infer");
	var name=document.getElementById("name");;
	var address=document.getElementById("address");
	var occupation=document.getElementById("occupation");
	
	
	
	if(fir.value==" "||action.value==" " || infer.value==" " ||name.value==" "|| address.value==" " || occupation.value==" ")
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	
	}
	else
		login();
		
	
}

function login()
{   
	$('noway').style.display="block";
	$('noway').innerHTML='<img src="../8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
		new Ajax.Request( '../actions/see_DT.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
		if( transport.responseText.match( /1/ ) )
	$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>Details updated successfully!!!</b></span>';
	if( transport.responseText.match( /0/ ) )
		$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Problem while updating Case Details!! try again..!!</b></span>';
	
	}
		} );
}	

