		function proof()
		{
		var type=document.getElementById("type").value;
		if(type==1)
		{
		document.getElementById("label-display").innerHTML='Passport No:<span style="color:red; font-size:14"><b>*</b></span>';
		document.getElementById("textbox-display").innerHTML='<input type="text" size="20" name="no" id="no" style="border: 1px solid black;" onblur="validateno()"/>';
		}
		if(type==2)
		{
		document.getElementById("label-display").innerHTML='Voter ID: <span style="color:red; font-size:14"><b>*</b></span>';
		document.getElementById("textbox-display").innerHTML='<input type="text" size="20" name="no" id="no" style="border: 1px solid black;" onblur="validateno()"/>';
		}
		if(type==3)
		{
		document.getElementById("label-display").innerHTML='Driving License No:<span style="color:red; font-size:14"><b>*</b></span>';
		document.getElementById("textbox-display").innerHTML='<input type="text" size="20" name="no" id="no" style="border: 1px solid black;" onblur="validateno()"/>';
		}
		
		}