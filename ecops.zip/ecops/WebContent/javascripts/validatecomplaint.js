function validatename()
			{
			var name=document.getElementById("name");
			if(name.value=="")
			{
				name.style.borderColor="red";
				document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
				document.getElementById("name-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("name-error").style.display="none";
			}
			}
function validatesubject()
{
	var subject=document.getElementById("subject");
	if(subject.value=="")
	{
		subject.style.borderColor="red";
		document.getElementById("subject-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Subject cannot be blank</span>';
		document.getElementById("subject-error").style.display="block";
	}  
else
	{
		subject.style.borderColor=" #00CC00";
		document.getElementById("subject-error").style.display="none";
	}
}
function validatecomplaint()
{
	var complaint=document.getElementById("complaint");
	if(complaint.value=="")
	{
		complaint.style.borderColor="red";
		document.getElementById("complaint-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Complaint cannot be blank</span>';
		document.getElementById("complaint-error").style.display="block";
	}  
else
	{
		complaint.style.borderColor="#00CC00";
		document.getElementById("complaint-error").style.display="none";
	}
}
function validateaddress()
{
	var address=document.getElementById("address");
	if(address.value=="")
	{
		address.style.borderColor="red";
		document.getElementById("address-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Address cannot be blank</span>';
		document.getElementById("address-error").style.display="block";
	}  
else
	{
		address.style.borderColor="#00CC00";
		document.getElementById("address-error").style.display="none";
	}
}
function validatecontno()
{
	var contno=document.getElementById("contno");
	if(contno.value=="")
	{
		contno.style.borderColor="red";
		document.getElementById("contno-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Contact Number cannot be blank</span>';
		document.getElementById("contno-error").style.display="block";
	}  
else
	{
	contno.style.borderColor="#00CC00";
		document.getElementById("contno-error").style.display="none";
	}
}
function validateemailid()
{
var emailid=document.getElementById("emailid");
if(emailid.value=="")
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot be blank</span>';
	document.getElementById("emailid-error").style.display="block";
} 
else if(emailid.value.indexOf(' ')>=0)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot have blank space</span>';
	document.getElementById("emailid-error").style.display="block";
}
else if(emailid.value.indexOf('@')==-1)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
	document.getElementById("emailid-error").style.display="block";
}
else if(emailid.value.indexOf('.')==-1)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
	document.getElementById("emailid-error").style.display="block";
}

else
{
emailid.style.borderColor=" #00CC00";
document.getElementById("emailid-error").style.display="none";
}
}
function validateform()
{
	var username=document.getElementById("name");
	var pstn=document.getElementById("pstn");
	var address=document.getElementById("address");
	var subject=document.getElementById("subject");
	var complaint=document.getElementById("complaint");
	var contno=document.getElementById("contno");
	var emailid=document.getElementById("emailid");
	if(username.value==""  || pstn.value=="-1" ||address.value=="" || subject.value=="" || complaint.value== "" || contno.value=="" || emailid.value=="")
	{
	document.getElementById("form-error").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("form-error").style.display="block";
	document.getElementById("noway").style.display="none";
	}
	else
	{
		document.getElementById("form-error").style.display="none";
		check();
	}
}
function check()
{
	$('noway').innerHTML='<img src="image/8-0.gif" /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-size:14;">PLEASE WAIT!</span>';
		new Ajax.Request( 'actions/see-complaint.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
			if( transport.responseText.match( /1/ ) )
			{
				$('noway').style.display="block";
				$('noway').innerHTML='<span style="margin-left:10; text-align:center; font-family:Arial; font-size:16; color:green"><b>THANK YOU..!! We received your complaint. Check your mail box for more details.</b></span>';
			}
    			if( transport.responseText.match( /0/ ) )
    			{		
  				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>Problem while receiving your complaint. Please try later!</b></span>';
  				$('noway').style.display="block";
    			}
    			}
		} );
}