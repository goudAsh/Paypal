function validate_fir()
{
var type=document.getElementById("fir");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("fir-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("fir-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("fir-error").style.display="none";
}
}


function validate_dst()
{
var type=document.getElementById("dst");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("dst-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("dst-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("dst-error").style.display="none";
}
}



function validate_statn()
{
var type=document.getElementById("statn");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("statn-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("statn-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("statn-error").style.display="none";
}
}


function validate_code()
{
var code=document.getElementById("code");
if(code.value=="Select")
{
	code.style.borderColor="red";
	document.getElementById("code-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Court code cannot be blank</span>';
	document.getElementById("code-error").style.display="block";
}  
else
{
	code.style.borderColor=" #00CC00";
document.getElementById("code-error").style.display="none";
}
}


function validate_casetype()
{
var case_type=document.getElementById("casetype");
if(case_type.value=="Select")
{
	case_type.style.borderColor="red";
	document.getElementById("case-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory</span>';
	document.getElementById("case-error").style.display="block";
}  
else
{
	case_type.style.borderColor=" #00CC00";
document.getElementById("case-error").style.display="none";
}
}

function validate_case()
{
var case_no=document.getElementById("caseno");
if(case_no.value=="")
{
	case_no.style.borderColor="red";
	document.getElementById("caseno-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Case no cannot be blank</span>';
	document.getElementById("caseno-error").style.display="block";
}  
else
{
	case_no.style.borderColor=" #00CC00";
document.getElementById("caseno-error").style.display="none";
}
}

function validate_pros()
{
var pros=document.getElementById("pros_name");
if(pros.value=="")
{
	pros.style.borderColor="red";
	document.getElementById("pros-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Prosecute name cannot be blank </span>';
	document.getElementById("pros-error").style.display="block";
}  
else
{
pros.style.borderColor=" #00CC00";
document.getElementById("pros-error").style.display="none";
}
}

function validate_date1()
{
var date1=document.getElementById("date1");
if(date1.value=="")
{
	date1.style.borderColor="red";
	document.getElementById("date1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Date cannot be blank </span>';
	document.getElementById("date1-error").style.display="block";
}  
else
{
	date1.style.borderColor=" #00CC00";
document.getElementById("date1-error").style.display="none";
}
}

function validateform()
{
		
	var fir=document.getElementById("fir");
	var dst=document.getElementById("dst");
	var statn=document.getElementById("statn");
	var code=document.getElementById("code");
	var caseno=document.getElementById("caseno");
	var pros_name=document.getElementById("pros_name");;
	var casetype=document.getElementById("casetype");
	var date1=document.getElementById("date1");
	
	
	
	
	if(pros_name.value==" " || fir.value=="Select" ||date1.value==" "|| dst.value=="Select" || statn.value== "Select" ||  code.value==" " || caseno.value == "" || casetype.value == "Select" )
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	}
	else
		login();
		
	
}


function login()
{   
	$('noway').style.display="block";
	$('noway').innerHTML='<b style="font-size:14;"> Please Wait!</b>';
		new Ajax.Request( '../actions/see_court.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
		if( transport.responseText.match( /1/ ) )
	$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>Court disposal updated successfully!!!</b></span>';
	if( transport.responseText.match( /0/ ) )
		$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Problem while updating Court disposal!!try again..!!</b></span>';
	
	}
		} );
}	
