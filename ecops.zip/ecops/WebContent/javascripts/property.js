
function validate_fir()
{
var type=document.getElementById("fir");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("fir-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("fir-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("fir-error").style.display="none";
}
}

function validate_name()
{
var name=document.getElementById("name");
if(name.value=="")
{
	name.style.borderColor="red";
	document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("name-error").style.display="block";
}  
else
{
name.style.borderColor=" #00CC00";
document.getElementById("name-error").style.display="none";
}
}

function validate_nature()
{
var nature=document.getElementById("nature");
if(nature.value=="Select")
{
	nature.style.borderColor="red";
	document.getElementById("nature-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("nature-error").style.display="block";
}  
else
{
	nature.style.borderColor=" #00CC00";
document.getElementById("nature-error").style.display="none";
}
}
function validate_kgid()
{
var kgid=document.getElementById("kgid");
if(kgid.value=="Select")
{
	kgid.style.borderColor="red";
	document.getElementById("kgid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">KGID cannot be blank</span>';
	document.getElementById("kgid-error").style.display="block";
}  
else
{
kgid.style.borderColor=" #00CC00";
document.getElementById("kgid-error").style.display="none";
}
}



function validateplace()
{
var place=document.getElementById("place");
if(place.value=="")
{
	place.style.borderColor="red";
	document.getElementById("place-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Place</span>';
	document.getElementById("place-error").style.display="block";
}  
else
{
	place.style.borderColor=" #00CC00";
document.getElementById("place-error").style.display="none";
}
}

function validatedesc()
{
var desc=document.getElementById("desc");
if(desc.value=="")
{
	desc.style.borderColor="red";
	document.getElementById("desc-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the place description</span>';
	document.getElementById("desc-error").style.display="block";
}  
else
{
	desc.style.borderColor=" #00CC00";
document.getElementById("desc-error").style.display="none";
}
}


function validate_email()
{
var emailid=document.getElementById("email-id");
if(emailid.value=="")
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot be blank</span>';
	document.getElementById("emailid-error").style.display="block";
} 
else if(emailid.value.indexOf(' ')>=0)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot have blank space</span>';
	document.getElementById("emailid-error").style.display="block";
}
else if(emailid.value.indexOf('@')==-1)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
	document.getElementById("emailid-error").style.display="block";
}
else if(emailid.value.indexOf('.')==-1)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
	document.getElementById("emailid-error").style.display="block";
}

else
{
emailid.style.borderColor=" #00CC00";
document.getElementById("emailid-error").style.display="none";
}
}


function validatedate1()
{
var date1=document.getElementById("date1");
if(date1.value=="")
{
	date1.style.borderColor="red";
	document.getElementById("date1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Date</span>';
	document.getElementById("date1-error").style.display="block";
}  
else
{
	date1.style.borderColor=" #00CC00";
document.getElementById("date1-error").style.display="none";
}
}

function validateform()
{
		
	var fir=document.getElementById("firno");
	 var dst=document.getElementById("dist");
	//var kgid=document.getElementById("kgid");
	var nature=document.getElementById("nature");
	var place=document.getElementById("place");
	var desc=document.getElementById("desc");
	var name=document.getElementById("name2");
	var date1=document.getElementById("date1");
	
	
	
	
	if(fir.value=="" || dst.value=="0" || nature.value=="0" || place.value=="" || desc.value=="" || name.value=="" || date1.value=="")
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	}
	else
		login();
		
	
}

function login()
{   
	$('noway').style.display="block";
	$('noway').innerHTML='<img src="../8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
		new Ajax.Request( '../actions/see_property.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
		if( transport.responseText.match( /1/ ) )
	$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>Added successfully!!!</b></span>';
	if( transport.responseText.match( /0/ ) )
		$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Problem while updating!! try again..!!</b></span>';
	
	}
		} );
}	