function validateform()
{
	var current=document.getElementById("current");
	var newp=document.getElementById("new");
	var renew=document.getElementById("renew");
	if(current.value.length==0)
	{
		document.getElementById("current-error").style.display="block";
		document.getElementById("current-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please Enter current password</span>';
	}
	else
	{
		document.getElementById("current-error").style.display="none";
	}	
	if(newp.value=="")
	{
		document.getElementById("new-error").style.display="block";
		document.getElementById("new-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please Enter New password</span>';
	}
	else
	{
		if(newp.value.length<=5)
		{
			document.getElementById("new-error").style.display="block";
			document.getElementById("new-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Password must have atleast 6 characters</span>';
		}
		else
		{
			document.getElementById("new-error").style.display="none";
		}
	}
	if(renew.value.length==0)
	{
		document.getElementById("renew-error").style.display="block";
		document.getElementById("renew-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please Re-confirm password</span>';
	}
	else
	{
		document.getElementById("renew-error").style.display="none";
	}
	if(renew.value!=newp.value && renew.value!=0 && newp.value!=0)
	{
		document.getElementById("noway").style.display="block";
		document.getElementById("noway").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Re-Eneterd password not matched! Please Try Again</span>';
	}
	else
	{
		document.getElementById("noway").style.display="none";
	}
	if(current.value.length!=0 && newp.value.length!=0 && renew.value.length!=0 && newp.value==renew.value)
	{
	check();
	}
}
	function check()
	{
		$('noway').style.display="block";
		$('noway').innerHTML='<img src="image/8-0.gif" /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-size:14;">PLEASE WAIT!</span>';
			new Ajax.Request( 'actions/see-changepassword.jsp',
			{
		method: 'post',
		postBody: $('logform').serialize(),
		onSuccess: function( transport ) {
				if( transport.responseText.match( /1/ ) )
				{
					$('noway').style.display="block";
					$('noway').innerHTML='<span style="margin-left:10; text-align:center; font-family:Arial; font-size:16; color:green"><b>Successfully changed your Password</b></span>';
				}
				else if( transport.responseText.match( /0/ ) )
	    			{		
	  				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>Invalid Current Password! Please try again.</b></span>';
	  				$('noway').style.display="block";
	    			}
				else
				{
					$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:16; color:red"><b>Problem while we receiving you request!! Try later.</b></span>';
	  				$('noway').style.display="block";
				}
				}
			} );
	}
