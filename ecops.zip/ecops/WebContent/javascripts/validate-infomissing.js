			function validatename()
			{
			var name=document.getElementById("name");
			if(name.value=="")
			{
				name.style.borderColor="red";
				document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
				document.getElementById("name-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("name-error").style.display="none";
			}
			}
			function validatecontactno()
			{
			var contactno=document.getElementById("contactno");
			if(contactno.value=="")
			{
				contactno.style.borderColor="red";
				document.getElementById("contactno-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Contact No cannot be blank</span>';
				document.getElementById("contactno-error").style.display="block";
			}  
			else
			{
				contactno.style.borderColor=" #00CC00";
			document.getElementById("contactno-error").style.display="none";
			}
			}
			function validatemessage()
			{
			var message=document.getElementById("message");
			if(message.value=="")
			{
				message.style.borderColor="red";
				document.getElementById("message-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Message cannot be blank</span>';
				document.getElementById("message-error").style.display="block";
			}  
			else
			{
				message.style.borderColor=" #00CC00";
			document.getElementById("message-error").style.display="none";
			}
			}
			function validateemailid()
			{
			var emailid=document.getElementById("emailid");
			if(emailid.value=="")
			{
				emailid.style.borderColor="red";
				document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot be blank</span>';
				document.getElementById("emailid-error").style.display="block";
			} 
			else if(emailid.value.indexOf(' ')>=0)
			{
				emailid.style.borderColor="red";
				document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot have blank space</span>';
				document.getElementById("emailid-error").style.display="block";
			}
	        else if(emailid.value.indexOf('@')==-1)
	        {
	        	emailid.style.borderColor="red";
				document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
				document.getElementById("emailid-error").style.display="block";
			}
	        else if(emailid.value.indexOf('.')==-1)
	        {
	        	emailid.style.borderColor="red";
				document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
				document.getElementById("emailid-error").style.display="block";
			}

			else
			{
			emailid.style.borderColor=" #00CC00";
			document.getElementById("emailid-error").style.display="none";
			}
			}
			function validateform()
			{
				var username=document.getElementById("name");
				var emailid=document.getElementById("emailid");
				var contactno=document.getElementById("contactno");
				var message=document.getElementById("message");
				if(name.value==""  || emailid.value=="" ||contactno.value=="" || message.value=="" )
				{
				document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
				document.getElementById("noway").style.display="block";
				}
				else
				{
					check();
				}
			}
			function check()
			{
				$('noway').innerHTML='<img src="image/8-0.gif" />&nbsp;&nbsp;&nbsp;<span style="font-size:14;">PLEASE WAIT!</span>';
					new Ajax.Request( 'actions/see-infomissing.jsp',
					{
				method: 'post',
				postBody: $('logform').serialize(),
				onSuccess: function( transport ) {
						if( transport.responseText.match( /1/ ) )
						{
							$('noway').style.display="block";
							$('noway').innerHTML='<span style="margin-left:10; text-align:center; font-family:Arial; font-size:14; color:green"><b>Successfully Informed !!</b></span>';
						}
			    			if( transport.responseText.match( /0/ ) )
			    			{		
			  				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>ERROR! Please try later.</b></span>';
			  				$('noway').style.display="block";
			    			}
			    			}
					} );
			}