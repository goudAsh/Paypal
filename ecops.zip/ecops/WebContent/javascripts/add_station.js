function validate_psname()
			{
			var name=document.getElementById("psname");
			if(name.value=="")
			{
				name.style.borderColor="red";
				document.getElementById("ps-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">PS name cannot be blank</span>';
				document.getElementById("ps-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("ps-error").style.display="none";
			}
			}



function validate_taluk()
{
var type=document.getElementById("taluk");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("taluk-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("taluk-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("taluk-error").style.display="none";
}
}

function validate_dst()
{
var type=document.getElementById("dst");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("dst-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("dst-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("dst-error").style.display="none";
}
}

function validate_area()
{
var type=document.getElementById("area");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("area-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("area-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("area-error").style.display="none";
}
}


function validateform()
{
	var psname=document.getElementById("psname");
	var add=document.getElementById("add");	
	var dst=document.getElementById("dst");
	

	if( psname.value=="" || dst.value=="Select" || add.value=="")
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	
	}
	else
	login();
}

function login()
{   
	$('noway').style.display="block";
	$('noway').innerHTML='<img src="../8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
		new Ajax.Request( '../actions/see_addstation.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
		if( transport.responseText.match( /1/ ) )
	$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>New police sation added successfully!!!</b></span>';
	if( transport.responseText.match( /0/ ) )
		$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Problem while creating police station!! try again..!!</b></span>';
	
	}
		} );
}	