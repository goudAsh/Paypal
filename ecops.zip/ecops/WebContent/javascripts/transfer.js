function validate_kgid()
			{
			var name=document.getElementById("kgid");
			if(name.value==" ")
			{
				name.style.borderColor="red";
				document.getElementById("kgid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">KGID cannot be blank</span>';
				document.getElementById("kgid-error").style.display="block";
			}  
			else
			{
			name.style.borderColor=" #00CC00";
			document.getElementById("kgid-error").style.display="none";
			}
			}


function validate_name()
{
var off_name=document.getElementById("name");
if(off_name.value=="")
{
	off_name.style.borderColor="red";
	document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Name cannot be blank</span>';
	document.getElementById("name-error").style.display="block";
}  
else
{
off_name.style.borderColor=" #00CC00";
document.getElementById("name-error").style.display="none";
}
}

function validate_desig()
{
var desig=document.getElementById("desig");
if(desig.value=="Select")
{
	desig.style.borderColor="red";
	document.getElementById("desig-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("desig-error").style.display="block";
}  
else
{
desig.style.borderColor=" #00CC00";
document.getElementById("desig-error").style.display="none";
}
}
	
function validate_email()
{
var emailid=document.getElementById("email-id");
if(emailid.value=="")
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot be blank</span>';
	document.getElementById("emailid-error").style.display="block";
} 
else if(emailid.value.indexOf(' ')>=0)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Email-ID cannot have blank space</span>';
	document.getElementById("emailid-error").style.display="block";
}
else if(emailid.value.indexOf('@')==-1)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
	document.getElementById("emailid-error").style.display="block";
}
else if(emailid.value.indexOf('.')==-1)
{
	emailid.style.borderColor="red";
	document.getElementById("emailid-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Invalid Email-ID. Please enter right one.</span>';
	document.getElementById("emailid-error").style.display="block";
}

else
{
emailid.style.borderColor=" #00CC00";
document.getElementById("emailid-error").style.display="none";
}
}




function validate_statn1()
{
var type=document.getElementById("statn1");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("statn1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("statn1-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("statn1-error").style.display="none";
}
}

function validate_statn2()
{
var type=document.getElementById("statn2");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("statn2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("statn2-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("statn2-error").style.display="none";
}
}


function validate_dst1()
{
var type=document.getElementById("dst1");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("dst1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("dst1-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("dst1-error").style.display="none";
}
}

function validate_dst2()
{
var type=document.getElementById("dst2");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("dst2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("dst2-error").style.display="block";
}  
else
{
type.style.borderColor=" #00CC00";
document.getElementById("dst2-error").style.display="none";
}
}


function validate_type()
{
var type=document.getElementById("type");
if(type.value=="Select")
{
	type.style.borderColor="red";
	document.getElementById("type-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("type-error").style.display="block";
}  
else
{
	type.style.borderColor=" #00CC00";
document.getElementById("type-error").style.display="none";
}
}

function validate_desig2()
{
var desig2=document.getElementById("desig2");
if(desig2.value=="Select")
{
	desig2.style.borderColor="red";
	document.getElementById("desig2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Select any catogory </span>';
	document.getElementById("desig2-error").style.display="block";
}  
else
{
desig2.style.borderColor=" #00CC00";
document.getElementById("desig2-error").style.display="none";
}
}






function validateform()
{
	var kgid=document.getElementById("kgid");
	var name=document.getElementById("name");
	var desig=document.getElementById("desig");
	var type=document.getElementById("type");
	var desig2=document.getElementById("desig2");
	var dst1=document.getElementById("dst1");
	var statn1=document.getElementById("statn1");
	var dst2=document.getElementById("dst2");
	var statn2=document.getElementById("statn2");
	var emailid=document.getElementById("emailid");
	
	if(kgid.value=="" || name.value=="" || desig.value=="Select" || dst1.value== "Select" || statn1.value=="Select" || emailid.value=="" ||dst2.value== "Select" || statn2.value=="Select" ||type.value=="Select" || desig2.value=="Select")
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	
	}
	else
		login();
}
function login()
{   
	$('noway').style.display="block";
	$('noway').innerHTML='<img src="../8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
		new Ajax.Request( '../actions/see_SP.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
		if( transport.responseText.match( /1/ ) )
	$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>Tranfers updated successfully!!!</b></span>';
	if( transport.responseText.match( /0/ ) )
		$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Problem while updating Transfer order!!try again..!!</b></span>';
	
	}
		} );
}	



