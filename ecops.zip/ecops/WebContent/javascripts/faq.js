

function validateform()
{
	var question=document.getElementById("question");
	
	
	
	if(question.value=="")
	{
	document.getElementById("noway").innerHTML='<br /><br /><span style="font-family:Arial; text-align:center; font-size:15; color:red"><b>WARNING:</b></span>&nbsp;<span style="font-family:Arial; text-align:center; font-size:13; color:black">All the mandatory (<span style="font-family:Arial; text-align:center; font-size:13; color:red">*</span>) fields are not entered. Please Enter!</span>';
	document.getElementById("noway").style.display="block";
	
	}
	else
	login();
}
	
function login()
{   
	$('noway').style.display="block";
	$('noway').innerHTML='<img src="../8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
		new Ajax.Request( '../actions/see_addfaq.jsp',
		{
	method: 'post',
	postBody: $('logform').serialize(),
	onSuccess: function( transport ) {
		if( transport.responseText.match( /1/ ) )
	$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>New police sation added successfully!!!</b></span>';
	if( transport.responseText.match( /0/ ) )
		$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Problem while creating police station!! try again..!!</b></span>';
	
	}
		} );
}	