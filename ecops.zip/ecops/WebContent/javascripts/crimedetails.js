

function validatename()
{
var name=document.getElementById("name");
if(name.value=="")
{
	name.style.borderColor="red";
	document.getElementById("name-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Name</span>';
	document.getElementById("name-error").style.display="block";
}  
else
{
name.style.borderColor=" #00CC00";
document.getElementById("name-error").style.display="none";
}
}

function validatestreet()
{
var street=document.getElementById("street");
if(street.value=="")
{
	street.style.borderColor="red";
	document.getElementById("street-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Street</span>';
	document.getElementById("street-error").style.display="block";
}  
else
{
	street.style.borderColor=" #00CC00";
document.getElementById("street-error").style.display="none";
}
}

function validatearea()
{
var area=document.getElementById("area");
if(area.value=="")
{
	area.style.borderColor="red";
	document.getElementById("area-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Area</span>';
	document.getElementById("area-error").style.display="block";
}  
else
{
	area.style.borderColor=" #00CC00";
document.getElementById("area-error").style.display="none";
}
}

function validatecity()
{
var city=document.getElementById("city");
if(city.value=="")
{
	city.style.borderColor="red";
	document.getElementById("city-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the City</span>';
	document.getElementById("city-error").style.display="block";
}  
else
{
	city.style.borderColor=" #00CC00";
document.getElementById("city-error").style.display="none";
}
}

function validatestate()
{
var state=document.getElementById("state");
if(state.value=="")
{
	state.style.borderColor="red";
	document.getElementById("state-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the State</span>';
	document.getElementById("state-error").style.display="block";
}  
else
{
	state.style.borderColor=" #00CC00";
    document.getElementById("state-error").style.display="none";
}
}

function validatestate1()
{
var state1=document.getElementById("state1");
if(state1.value=="")
{
	state1.style.borderColor="red";
	document.getElementById("state1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the State</span>';
	document.getElementById("state1-error").style.display="block";
}  
else
{
	state1.style.borderColor=" #00CC00";
    document.getElementById("state1-error").style.display="none";
}
}


function validateplace()
{
var place=document.getElementById("place");
if(place.value=="")
{
	place.style.borderColor="red";
	document.getElementById("place-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Place</span>';
	document.getElementById("place-error").style.display="block";
}  
else
{
	place.style.borderColor=" #00CC00";
document.getElementById("place-error").style.display="none";
}
}


function validatedesc()
{
var desc=document.getElementById("desc");
if(desc.value=="")
{
	desc.style.borderColor="red";
	document.getElementById("desc-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the place description</span>';
	document.getElementById("desc-error").style.display="block";
}  
else
{
	desc.style.borderColor=" #00CC00";
document.getElementById("desc-error").style.display="none";
}
}


function validateoccup()
{
var occupation=document.getElementById("occupation");
if(occupation.value=="")
{
	occupation.style.borderColor="red";
	document.getElementById("occupation-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Occupation</span>';
	document.getElementById("occupation-error").style.display="block";
}  
else
{
	occupation.style.borderColor=" #00CC00";
document.getElementById("occupation-error").style.display="none";
}
}


function validatelang()
{
var lang=document.getElementById("lang");
if(lang.value=="")
{
	lang.style.borderColor="red";
	document.getElementById("lang-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Languages</span>';
	document.getElementById("lang-error").style.display="block";
}  
else
{
	lang.style.borderColor=" #00CC00";
document.getElementById("lang-error").style.display="none";
}
}


function validatedate()
{
var date=document.getElementById("date");
if(date.value=="")
{
	date.style.borderColor="red";
	document.getElementById("date-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Date</span>';
	document.getElementById("date-error").style.display="block";
}  
else
{
	date.style.borderColor=" #00CC00";
document.getElementById("date-error").style.display="none";
}
}

function validatedate1()
{
var date1=document.getElementById("date1");
if(date1.value=="")
{
	date1.style.borderColor="red";
	document.getElementById("date1-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Date</span>';
	document.getElementById("date1-error").style.display="block";
}  
else
{
	date1.style.borderColor=" #00CC00";
document.getElementById("date1-error").style.display="none";
}
}

function validatedate2()
{
var date2=document.getElementById("date2");
if(date2.value=="")
{
	date2.style.borderColor="red";
	document.getElementById("date2-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Date</span>';
	document.getElementById("date2-error").style.display="block";
}  
else
{
	date2.style.borderColor=" #00CC00";
document.getElementById("date2-error").style.display="none";
}
}

function validatedate3()
{
var date3=document.getElementById("date3");
if(date3.value=="")
{
	date3.style.borderColor="red";
	document.getElementById("date3-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Date</span>';
	document.getElementById("date3-error").style.display="block";
}  
else
{
	date3.style.borderColor=" #00CC00";
document.getElementById("date3-error").style.display="none";
}
}

function validatedate4()
{
var date4=document.getElementById("date4");
if(date4.value=="")
{
	date4.style.borderColor="red";
	document.getElementById("date4-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Date</span>';
	document.getElementById("date4-error").style.display="block";
}  
else
{
	date4.style.borderColor=" #00CC00";
document.getElementById("date4-error").style.display="none";
}
}

function validatehgt()
{
var hgt=document.getElementById("hgt");
if(hgt.value=="")
{
	hgt.style.borderColor="red";
	document.getElementById("hgt-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Height</span>';
	document.getElementById("hgt-error").style.display="block";
}  
else
{
	hgt.style.borderColor=" #00CC00";
document.getElementById("hgt-error").style.display="none";
}
}

function validatephycond()
{
var phycond=document.getElementById("phycond");
if(phycond.value=="")
{
	phycond.style.borderColor="red";
	document.getElementById("phycond-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Please enter the Physical Condition</span>';
	document.getElementById("phycond-error").style.display="block";
}  
else
{
	phycond.style.borderColor=" #00CC00";
document.getElementById("phycond-error").style.display="none";
}
}

function validateform()
{	var firno=document.getElementById("firno");
	var date=document.getElementById("date");
	var pstn=document.getElementById("pstn");
	var name=document.getElementById("name");
	var street=document.getElementById("street");
	var area=document.getElementById("area");
	var state=document.getElementById("state");
	var city=document.getElementById("city");
	var kgid=document.getElementById("kgid");
	var name2=document.getElementById("name2");
	if(firno.value==" " || date.value==" " || pstn.value==" " || name.value==" " || city.value==" " || kgid.value==" " || name2.value==" " || street.value==" " 
		|| area.value==" " || state.value==" ")
	{
	document.getElementById("form-error").innerHTML='<span style="font-family:Arial; font-size:13; color:red">Warning:Please enter all the fields</span>';
	document.getElementById("form-error").style.display="block";
	}
	else
	{
document.getElementById("form-error").style.display="none";
crimedetail();
	}
}
function crimedetail()
{
$('form-error').style.display="block";
$('form-error').innerHTML='<img src="../image/8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
	new Ajax.Request( '../actions/see-crimedetail.jsp',
	{
method: 'post',
postBody: $('logform').serialize(),
onSuccess: function( transport ) {
	if( transport.responseText.match( /1/ ) )
$('form-error').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>Inserted Successfully!</b></span>';
if( transport.responseText.match( /0/ ) )
	$('form-error').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Insertion Failed! Try Again.</b></span>';

}
	} );

}


