 
	  			
				function login()
				{
					$('noway').innerHTML='<img src="../image/8-0.gif" /><b style="font-size:14;"> Please Wait!</b>';
  					new Ajax.Request( 'see.jsp',
  					{
    				method: 'post',
    				postBody: $('logform').serialize(),
    				onSuccess: function( transport ) {
      				if( transport.responseText.match( /1/ ) )
        			$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:green"><b>Inserted Successfully!</b></span>';
        			if( transport.responseText.match( /0/ ) )
      				$('noway').innerHTML='<span style="margin-left:50; font-family:Arial; font-size:14; color:red"><b>Insertion Failed! Try Again.</b></span>';
        			
    				}
  					} );
				}
