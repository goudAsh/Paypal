
public class Movies {
	private	String movieName;
	private int 	movie_id;
	
	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	
	public int getMovieId(){
		return this.movie_id;
	}
	public void setMovieId(int id){
		this.movie_id = id;
	}
	
	
	
	
}
