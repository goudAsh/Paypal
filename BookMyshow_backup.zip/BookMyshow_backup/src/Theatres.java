
public class Theatres {

		String Tname;
		Movies movies;
		int 	Tid;
		
	
}
