
public class Theatres {
	int theatre_id;
	String theatre_name;
	int theatre_price;

		
	public int getTheatre_id() {
		return theatre_id;
	}
	public void setTheatre_id(int theatre_id) {
		this.theatre_id = theatre_id;
	}
	public String getTheatre_name() {
		return theatre_name;
	}
	public void setTheatre_name(String theatre_name) {
		this.theatre_name = theatre_name;
	}
	public int getTheatre_price() {
		return theatre_price;
	}
	public void setTheatre_price(int theatre_price) {
		this.theatre_price = theatre_price;
	}
	
	
}
