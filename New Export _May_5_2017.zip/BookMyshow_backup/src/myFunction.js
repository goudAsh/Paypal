/**
 * 
 */

function getMovielist(){
	
	
	alert("say hello");
}