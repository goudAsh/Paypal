package com.bms.paypal;

public class City {

	String cName;
	int cID;
	Movie movieName;
	
	
	public String getcName() {
		return cName;
	}
	
	public void setcName(String cName) {
		this.cName = cName;
	}
	
	public int getcID() {
		return cID;
	}
	
	public void setcID(int cID) {
		this.cID = cID;
	}
}
