package com.bms.paypal;


import java.sql.*;

public class SQLConnection {

	
	static Connection getConnection(){
		
	  Connection con=null;
		try{  
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bms","root","SqlRoot3!");  
		}
		
		catch(Exception e){ System.out.println(e);}  
		
		finally{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return con;
	
	}
}

